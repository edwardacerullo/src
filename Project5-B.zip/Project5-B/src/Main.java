import Project5B.MySQLInquiry;

public class Main {
	
    public static void main(String[] args) throws Exception {
    	
        MySQLInquiry p5b = new MySQLInquiry();
        p5b.readTables();
        
    }

}