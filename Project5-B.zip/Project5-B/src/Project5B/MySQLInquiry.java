package Project5B;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySQLInquiry {

	private Connection connection = null;
	private Statement statement = null;
	private ResultSet genericOutput = null;

	public void readTables() throws Exception {
		try {

			// Load the JDBC Driver - only once, I think?
			Class.forName("com.mysql.jdbc.Driver");

			// Connect to the Database
			connection = DriverManager
					.getConnection("jdbc:mysql://localhost/ntnu?"
							+ "user=EAC&password=Root");

			// Setup the statement to use the Database.
			statement = connection.createStatement();

			// Set the ISBN for the inquiries.
			String isbnRequest = "0-596-00123-1";
			
			// Do the first ISBN inquiry.
			String sqlStatement = "select isbn, forfatter, tittel from boktittel where isbn = " + "'" + isbnRequest + "'" + ";";
			genericOutput = statement
					.executeQuery(sqlStatement);

			while (genericOutput.next()) {

				String isbn = genericOutput.getString(1);
				String forfatter = genericOutput.getString(2);
				String tittel = genericOutput.getString(3);

				System.out.println("ISBN is " + isbn + " Forfatter is "
						+ forfatter + " Tittle is " + tittel);

			}

			// Do the second count inquiry.
			sqlStatement = "select count(*) antall from eksemplar where isbn = " + "'" + isbnRequest + "'" + ";";
			genericOutput = statement
					.executeQuery(sqlStatement);

			while (genericOutput.next()) {

				String count = genericOutput.getString(1);

				System.out.println("Count is " + count);

			}
			
		} catch (Exception error1) {

			throw error1;

		} finally {

			closeupdatabase();

		}

		return;

	}

	/*
	 *  Close up the NTNU database
	 */
	
	private void closeupdatabase() {
		try {

			if (connection != null) {
				connection.close();
			}

		} catch (Exception error2) {

			System.out.print("Error on NTNU database close: " + error2);

		}

	}
	
}