
/*
 * �ving1, Videreg�ende programmering i Java
 * Due: 03.02.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

import javax.swing.*;

class �ving1 {

	/* All-purpose variable */
	String okNok = " ";

	public static void main(String[] args) {

		/*
		 * Test 1:
		 * 
		 * - Establish the name, establishment date and number of tables for
		 * your resturant. - Change the name. - Calculate the age and display
		 * only the year from the establishment date.
		 * 
		 */
		String rn = JOptionPane.showInputDialog("Hello. Please enter a name for your restaurant...");
		String rd = JOptionPane
				.showInputDialog("And, please enter the date your restaurant opened, in the format ddmmyyyy...");
		String tb = JOptionPane.showInputDialog("Finally, please enter the number of tables in your restaurant...");
		int tn = Integer.parseInt(tb); /* Do some converting here... */
		String[] ta = new String[tn];
		Restaurant myRestaurant = new Restaurant(rn, rd, ta);

		System.out.println("The Restaurant is named " + myRestaurant.getRestaurantName() + " and it is "
				+ myRestaurant.getRestaurantAge() + " years old.");

		rn = JOptionPane.showInputDialog(
				"Unfortunately, the Br�nn�ysundregistrene has rejected the name you entered. Please enter a new name for your restaurant...");
		myRestaurant.populateRestaurantName(rn);
		System.out.println("The Restaurant is now re-named " + myRestaurant.getRestaurantName()
				+ " and it was founded in " + myRestaurant.getEstablishmentYear() + " -- which was a fine year!");

		/*
		 * Test 2:
		 * 
		 * Management Report - Count the empty tables. - Count the reserved
		 * tables.
		 * 
		 */

		myRestaurant.managementReport();

		/*
		 * Test 3:
		 * 
		 * - Reserve a table.
		 * 
		 */

		myRestaurant.reserveTablesForACustomer("John Wayne", 1);

		myRestaurant.reserveTablesForACustomer("James Stewart", 1);

		myRestaurant.reserveTablesForACustomer("Lucille Ball", 1);

		myRestaurant.reserveTablesForACustomer("Maureen O'Hara", 1);
		myRestaurant.managementReport();

		/*
		 * Test 4:
		 * 
		 * - Reserve all the tables.
		 * 
		 */

		myRestaurant.reserveTablesForACustomer("Marion Robert Morrison", 14);
		myRestaurant.managementReport();

		/*
		 * Test 5:
		 * 
		 * - Clear a table
		 * 
		 */

		myRestaurant.clearTables(7);
		myRestaurant.managementReport();

		/*
		 * Test 6:
		 * 
		 * - Find a customer.
		 */

		myRestaurant.whichTableAPersonHas("Maureen O'Hara");

	}

}

/*
 * * * * * * * * * * * * * * * * * * * * * * * Restaurant * * * * * * * * * * *
 * * * * * * * * * * * *
 */

class Restaurant {

	private String restaurantName;
	private String establishmentDate;
	private String[] tables;

	public Restaurant(String restaurantName, String establishmentDate, String[] tables) {
		this.restaurantName = restaurantName;
		this.establishmentDate = establishmentDate;
		this.tables = tables;
	}

	/* The find operations: */

	/* 1. Finn navnet p� restauranten */
	public String getRestaurantName() {

		return restaurantName;

	}

	/* 3. Finn etablerings�ret */
	public String getEstablishmentYear() {

		/*
		 * TODO: I don't know why the substring end value has to be 8; it should
		 * be 7. Java counts strange, mayhaps?
		 */
		return (establishmentDate.substring(4, 8));

	}

	/* 4. Finn hvor gammel restauranten er */
	public int getRestaurantAge() {

		DateTimeFormatter format = DateTimeFormatter.ofPattern("ddMMyyyy");
		Period periode = Period.between(LocalDate.parse(establishmentDate, format), LocalDate.now());
		return periode.getYears();

	}

	/* 5. Finn antall ledige bord */
	public int getNumberOfFreeTables() {

		int numberOfUnreservedTables = 0;
		for (int x = 0; x < tables.length; x++) {

			if (tables[x] == null) {

				numberOfUnreservedTables = numberOfUnreservedTables + 1;

			}

		}

		return numberOfUnreservedTables;

	}

	/* 6. Finn antall bord opptatt */
	public int getNumberOfTablesInUse() {

		int numberOfTablesInUse = 0;
		for (int x = 0; x < tables.length; x++) {

			if (tables[x] != null) {

				numberOfTablesInUse = numberOfTablesInUse + 1;

			}

		}

		return numberOfTablesInUse;

	}

	/*
	 * 8. Finn hvilke bord en bestemt person har reservert, bordnumrene skal
	 * returnes som int[]
	 */
	public int whichTableAPersonHas(String customerName) {

		int tableNumber = 0;
		for (int x = 0; x < tables.length; x++) {

			if (tables[x] == customerName) {

				tableNumber = x + 1;
				System.out.println("Customer " + customerName + " is at table " + tableNumber);
			}

		}

		return tableNumber;

	}

	/* The update operations: */

	/* 2. Populate the name */
	public void populateRestaurantName(String newRestaurantName) {

		restaurantName = newRestaurantName;

		return;

	}

	/* 7. Reserver et bestemt antall bord p� �n person (et navn) */
	public void reserveTablesForACustomer(String customerName, int numberOfTables) {

		/*
		 * Loop thru the table array Find the first available table and assign
		 * the customer to that.
		 * 
		 */

		for (int x = 0; x < tables.length; x++) {

			if (tables[x] == null) {

				if (numberOfTables > 0) {
					System.out.println("Table " + x + " is available... Right this way, please!");
					tables[x] = customerName;
					System.out.println(customerName + " " + numberOfTables + " tables requested further. ");
					numberOfTables = numberOfTables - 1;
				}

			}

		}

		if (numberOfTables > 0) {
			System.out.println("Restaurant at Capacity. Not enough tables for your request.");
		} else {
			System.out.println("Reservation has been successfully made");
		}

		return;
	}

	/* 9. Frigi bord som er ryddet, bordnumrene skal sendes inn som int[] */
	public void clearTables(int tableNumber) {

		for (int x = 0; x < tables.length; x++) {

			if (x == (tableNumber - 1)) {

				tables[x] = null;
				System.out.println("Table " + tableNumber + " was cleared.");

			}

		}

		return;

	}

	/* 10. Populate the establishment date */
	public String populateEstablishmentDate(String newEstablishmentDate) {

		establishmentDate = newEstablishmentDate;
		String okNok = "OK";

		return okNok;

	}

	/* 11. Management Report */

	public void managementReport() {

		System.out.println("===" + getRestaurantName() + "===");
		System.out.println("- Reserved tables: " + getNumberOfTablesInUse());
		System.out.println("- Unreserved tables: " + getNumberOfFreeTables());

		return;
	}

	/*
	 * * * * * * * * * * * * * * * * * * * * * * * Tables * * * * * * * * * * *
	 * * * * * * * * * * * *
	 */

	class Bord {

		/* 1. Finn antall ledige bord */
		public int findNumberOfUnreservedTables() {

			int numberOfUnreservedTables = 0;
			for (int x = 0; x < tables.length; x++) {

				if (tables[x] == null) {

					numberOfUnreservedTables = numberOfUnreservedTables + 1;

				}

			}

			return numberOfUnreservedTables;

		}

		/* 2. Finn antall bord opptatt */
		public int findNumberOfReservedTables() {

			int numberOfReservedTables = 0;
			for (int x = 0; x < tables.length; x++) {

				if (tables[x] != null) {

					numberOfReservedTables = numberOfReservedTables + 1;

				}

			}

			return numberOfReservedTables;

		}

		/* 3. Frigi bord som er ryddet */
		public void clearATable(int tableNumber) {

			for (int x = 0; x < tables.length; x++) {

				if (x == (tableNumber - 1)) {

					tables[x] = null;
					System.out.println("Table " + tableNumber + " was cleared.");

				}

			}

			return;

		}

		/* 4. Reserver bord */
		public void reserveATable(String customerName, int numberOfTables) {

			/*
			 * Loop thru the table array Find the first available table and
			 * assign the customer to that.
			 * 
			 */

			for (int x = 0; x < tables.length; x++) {

				if (tables[x] == null) {

					if (numberOfTables > 0) {
						System.out.println("Found a table at " + tables[x]);
						tables[x] = customerName;
						System.out.println(customerName + " " + numberOfTables + " tables. Right this way!");
						numberOfTables = numberOfTables - 1;
					}

				}

			}

			if (numberOfTables > 0) {
				System.out.println("Restaurant is at Capacity. Not enough tables for your request.");
			} else {
				System.out.println("Reservation has been successfully made");
			}

			return;

		}

	}
}