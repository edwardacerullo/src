import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class �ving10B extends JFrame {
	
	/**
	 * Eclipse wants to put this in.
	 */
	private static final long serialVersionUID = 1L;
	
	public static void main (String[] args) {
	
		System.out.println("This is the main.");
		
		�ving10B();
		
		System.out.println("This is the return.");
		return;
		
		}

	/*
	 * This is the guts.
	 */
	private static void �ving10B() {

		System.out.println("This is the start.");
		// Next, the frame.
		JFrame frame1 = new JFrame("Valutakalkulator");

		// Next, a label field.
		JLabel label1 = new JLabel();
		label1.setText("Bel�p:");
		label1.setFont(new Font("Serif", Font.PLAIN, 24));
		label1.setForeground(Color.ORANGE);
		label1.setBounds(135, 100, 100, 50);
		frame1.add(label1);

		// Then, a text field.
		JTextField text1 = new JTextField("");
		text1.setBounds(250, 100, 100, 50);
		text1.setFont(new Font("Monospaced", Font.PLAIN, 24));
		frame1.add(text1);

		// Next, a label field.
		JLabel label2 = new JLabel();
		label2.setText("Vennligst enter en Bel�p.");
		label2.setFont(new Font("Arial", Font.PLAIN, 18));
		label2.setForeground(Color.MAGENTA);
		label2.setBounds(100, 175, 300, 50);
		frame1.add(label2);

		
		// And finally, buttons.
		JButton button1, button2;

		button1 = new JButton("Til Svensk.");
		button1.setBounds(100, 250, 150, 40);
		button1.setFont(new Font("Serif", Font.PLAIN, 24));
		button1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e1) {
				
				doTheCalc(button1, text1);
			}
			
		});
		frame1.add(button1);

		button2 = new JButton("Til Norsk.");
		button2.setBounds(300, 250, 150, 40);
		button2.setFont(new Font("Serif", Font.PLAIN, 24));
		button2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e2) {
				
				doTheCalc(button2, text1);
			}
			
		});

		frame1.add(button2);

		// Calculate
		/*label2.setText("Here's your calculation.");
		label2.setFont(new Font("Arial", Font.PLAIN, 18));
		label2.setForeground(Color.RED);
		*/

		// Finish up.
		frame1.setLayout(null);
		frame1.setSize(500, 500);
		frame1.setVisible(true);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		System.out.println("This is the end.");
	}
	
	private static void doTheCalc(JButton buttonX, JTextField text1) {
		
		System.out.println("This is the SWITCH. What have we:");
		System.out.println(buttonX.getFont().getFontName());
		/*
		 * Set the values.
		 * Add some color, to make the output more interesting.
		 */
		switch(buttonX.getText()) {
		
			// Amount entered is Norsky Rubles. Switch to Swedish Pesetas.
			case "Til Svensk.":
				String doshAmountSwedish = text1.getText();
				System.out.println("Pesetas = " + doshAmountSwedish);
				try {

					int doshAmountSwedishInt = Integer.parseInt(doshAmountSwedish);
					System.out.println("Pesetas Int = " + doshAmountSwedishInt);
					
				} catch (NumberFormatException errnfe) {
					
					errnfe.printStackTrace();
					System.out.println("Pesetas are no bueno.");
					
					
				}
		            
				break;

				// Amount entered is Swedish Pesetas. Switch to Norsky Rubles.
			case "Til Norsk.":
				String doshAmountNorsky = text1.getText();
				System.out.println("Rubles = " + doshAmountNorsky);
				try {
					
					int doshAmountNorskyInt = Integer.parseInt(doshAmountNorsky);
					System.out.println("Rubles Int = " + doshAmountNorskyInt);
					
				} catch (NumberFormatException errnfe) {
					
					errnfe.printStackTrace();
					System.out.println("Rubles are ne khorosho.");
					
				}

				break;
				
		}
		
	}

}