import static javax.swing.JOptionPane.*;
/* And now we need this import... */
import java.util.ArrayList;

/**
 * 
 * Program som kan brukes til � pr�ve ut metodene laget i �ving 1.
 * 
 * Om det er vanskelig � lese, kan det kanskje v�re p� sin plass � repetere
 * litt:
 * 
 * Brukergrensesnittet er lagt til en egen klasse, se kapittel 6.4, side 193.
 * For �vrig er et menystyrt program vist i kapittel 9.6, side 304.
 */

class GodkjenningBGS {
	public final String NY_STUDENT = "Ny student";
	public final String AVSLUTT = "Avslutt";
	private String[] muligeValg = { NY_STUDENT, AVSLUTT }; // f�rste gang, ingen
															// studenter
															// registrert

	private OppgaveOversikt oversikt;

	public GodkjenningBGS(OppgaveOversikt oversikt) {
		this.oversikt = oversikt;
	}

	/**
	 * 
	 * Metoden leser inn valget som en streng, og returnerer den. Valget skal
	 * v�re argument til metoden utf�rValgtOppgave(). Hvis programmet skal
	 * avsluttes, returneres null.
	 */
	public String lesValg() {
		int antStud = oversikt.finnAntStud();
		String valg = (String) showInputDialog(null, "Velg fra listen, "
				+ antStud + " studenter:", "Godkjente oppgaver",
				DEFAULT_OPTION, null, muligeValg, muligeValg[0]);
		if (AVSLUTT.equals(valg)) {
			valg = null;
		}
		return valg;
	}

	/**
	 * 
	 * Metode som s�rger for at �nsket valg blir utf�rt.
	 */
	public void utf�rValgtOppgave(String valg) {
		if (valg != null && !valg.equals(AVSLUTT)) {
			if (valg.equals(NY_STUDENT)) {
				registrerNyStudent();
			} else {
				registrerOppgaver(valg); // valg er navnet til studenten
			}
		}
	}

	/**
	 * 
	 * Metoden registrere ny student. Hvis student med dette navnet allerede
	 * eksisterer, skjer ingen registrering. Resultatet av operasjonen skrives
	 * ut til brukeren.
	 */
	private void registrerNyStudent() {
		String navnNyStud = null;
		do {
			navnNyStud = showInputDialog("Oppgi navn: ");
		} while (navnNyStud == null);

		navnNyStud = navnNyStud.trim();
		if (oversikt.regNyStudent(navnNyStud)) {
			showMessageDialog(null, navnNyStud + " er registrert.");
			String[] alleNavn = oversikt.finnAlleNavn();
			String[] nyMuligeValg = new String[alleNavn.length + 2];
			for (int i = 0; i < alleNavn.length; i++) {
				nyMuligeValg[i] = alleNavn[i];
			}
			nyMuligeValg[alleNavn.length] = NY_STUDENT;
			nyMuligeValg[alleNavn.length + 1] = AVSLUTT;
			muligeValg = nyMuligeValg;
		} else {
			showMessageDialog(null, navnNyStud + " er allerede registrert.");
		}
	}

	/**
	 * 
	 * Metoden registrerer oppgaver for en navngitt student. Brukerinput
	 * kontrolleres ved at det m� kunne tolkes som et tall. Registreringsmetoden
	 * (i klassen Student) kan kaste unntaksobjekt IllegalArgumentException.
	 * Dette fanges ogs� opp. I begge tilfeller m� brukeren gjenta inntasting
	 * inntil ok data. Endelig skrives det ut en melding om antall oppgaver
	 * studenten n� har registrert.
	 */
	private void registrerOppgaver(String studNavn) {
		String melding = "Oppgi antall nye oppgaver som skal godkjennes for "
				+ studNavn + ": ";
		int antOppg�kning = 0;
		boolean registrert = false;
		do { // gjentar inntil registrering aksepteres av objektet oversikt
			try {
				antOppg�kning = lesHeltall(melding);
				oversikt.�kAntOppg(studNavn, antOppg�kning); // kan ikke
																// returnere
																// false, pga
																// navn alltid
																// gyldig
				registrert = true; // kommer hit bare dersom exception ikke blir
									// kastet
			} catch (IllegalArgumentException e) { // kommer hit hvis studenter
													// f�r negativt antall
													// oppgaver
				melding = "Du skrev " + antOppg�kning
						+ ". \nIkke godkjent �kning for " + studNavn
						+ ". Pr�v igjen: ";
			}
		} while (!registrert);

		melding = "Totalt antall oppgaver registrert p� " + studNavn + " er "
				+ oversikt.finnAntOppgaver(studNavn) + ".";
		showMessageDialog(null, melding);
	}

	/* Hjelpemetode som g�r i l�kke inntil brukeren skriver et heltall. */
	private int lesHeltall(String melding) {
		int tall = 0;
		boolean ok = false;
		do { // gjentar inntil brukerinput kan tolkes som tall
			String tallLest = showInputDialog(melding);
			try {
				tall = Integer.parseInt(tallLest);
				ok = true;
			} catch (Exception e) {
				showMessageDialog(null,
						"Kan ikke tolke det du skrev som tall. Pr�v igjen. ");
			}
		} while (!ok);
		return tall;
	}
}

/* Class to track how many tasks have been approved for each student. */
/*
 * Part 2 -- replace the table with an array.
 */
class OppgaveOversikt {

	private ArrayList<Student> studenter = new ArrayList<Student>();
	private int antStud = 0;

	/*
	 * Register a new student. Return true if the student is not already
	 * registered and is registered here. 
	 * Return false if the student has already been registered.
	 */
	public boolean regNyStudent(String navn) {

		/*
		 * This is waaay simpler using an array. 
		 */

		for (Student student : studenter) {

			if (navn.equals(student.getNavn())) {
				return false;
			}

		}

		/* Add the new student */
		studenter.add(new Student(navn));
		antStud = antStud + 1;
		return true;

	}

	/* Find the number of Students */
	public int finnAntStud() {

		return antStud;

	}

	/* Find the number of approved tasks for the student. */
	public int finnAntOppgaver(String navn) {

		int antOppg = 0;

		for (Student student : studenter) {

			if (navn.equals(student.getNavn())) {

				antOppg = student.getAntOppg();

			}

		}

		return antOppg;
	}

	/* Increase the number of tasks for the student */
	public boolean �kAntOppg(String navn, int �kning) {

		int NyOppgAnt = 0;
		for (Student student : studenter) {

			if (navn.equals(student.getNavn())) {

				NyOppgAnt = student.getAntOppg() + �kning;
				student.setAntOppg(NyOppgAnt);

				return true;

			}

		}

		return false;

	}

	/* List all the names of the students */
	public String[] finnAlleNavn() {

		String[] alleNavns = new String[studenter.size()];
	    
		for(Student student : studenter) {
			
		      alleNavns[studenter.indexOf(student)] = student.getNavn();			
			
		}
		
		return alleNavns;

	}

	/* Convert to a string */
	public String toString() {

		String printLine = "========================================== \n";
	    for (Student student : studenter) {
	    	
	    	int printAnt = 0;
	    	printAnt = student.getAntOppg();
	    	
	      printLine += "Name: " + student + ", antall oppgaver l�st: " + printAnt + "\n";
	      
	    }
	    
	    return printLine;

	}

}

class Student {

	private final String navn;
	private int antOppg = 0;

	public Student(String navn) {

		if (navn == null) {

			throw new IllegalArgumentException("Name must be entered.");

		}

		this.navn = navn.trim();

	}

	/* Method to set the number of approved tasks for the student */
	public void setAntOppg(int nyAntOppg) {

		if (nyAntOppg < 0) {

			throw new IllegalArgumentException(
					"Number of approved student tasks may not be less than zero.");

		} else {
			
			this.antOppg = this.antOppg + nyAntOppg;			
			
		}

	}
	
	/* Method to get the name. */
	public String getNavn() {

		return navn;
	}

	/* Method to ge the number of approved tasks for the student */
	public int getAntOppg() {

		return antOppg;

	}

	/* Method to populate the Student name. */
	public String toString() {

		String returnText = null;
		returnText = navn;
		return returnText;
		
	}
	
}

/**
 * Hovedprogrammet. G�r i l�kke og lar brukeren gj�re valg.
 */
class Oppgave1 {
	public static void main(String[] args) {

		OppgaveOversikt oversikt = new OppgaveOversikt();
		GodkjenningBGS bgs = new GodkjenningBGS(oversikt);

		String valg = bgs.lesValg();
		while (valg != null) {
			bgs.utf�rValgtOppgave(valg);
			valg = bgs.lesValg();
		}

		/* Pr�ver toString() */
		System.out.println("\nHer kommer informasjon om alle studentene: ");
		System.out.println(oversikt);
	}

}