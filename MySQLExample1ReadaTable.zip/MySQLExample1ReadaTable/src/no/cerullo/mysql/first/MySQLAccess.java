package no.cerullo.mysql.first;

import java.sql.*;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class MySQLAccess {

 	public void readDataBase() throws Exception {
 
 		System.out.println("Defining the data source...");
 		MysqlDataSource dataSource = new MysqlDataSource();
 		dataSource.setUrl("jdbc:mysql://mur.timeanddate.net/QA");
 		dataSource.setUser("eac");
 		dataSource.setPassword("Time0123&");
 		
 		System.out.println("Connecting...");
 		Connection conn = dataSource.getConnection();
 		
 		// Initialize the statement variable
 		Statement stmt = null;
 	    String query = "SELECT * FROM `comments`;";
 	    
 	    try {
 	    	
 	    	stmt = conn.createStatement();
 	    	ResultSet rset = stmt.executeQuery(query);
 	    
 	    	// Loop
 	    	while (rset.next()) {
 	    		Object id = rset.getInt("id");
 	    		Object MYUSER = rset.getString("MYUSER");
 	    		Object EMAIL = rset.getString("EMAIL");
 	    		Object WEBPAGE = rset.getString("WEBPAGE");
 	    		Object DATUM = rset.getDate("DATUM");
 	    		Object SUMMARY = rset.getString("SUMMARY");
 	    		Object COMMENTS = rset.getString("COMMENTS");
 	    		
 	    		System.out.println(id + " " +
 	    				MYUSER + " " +
 	    				EMAIL + " " +
 	    				WEBPAGE  + " " +
 	    				DATUM  + " " +
 	    				SUMMARY  + " " +
 	    				COMMENTS);
 	    	}
 	    	
 	 		System.out.println("Closing result set...");
 	 		rset.close();
 	    	
 	    } catch (SQLException e ) {
 	        // TODO
 	    } finally {
 	        if (stmt != null) { stmt.close(); }
 	    }
 	     		
 		System.out.println("Closing statement...");
 		stmt.close();
 		System.out.println("Closing connection...");
 		conn.close(); 		
 		
    }

}