import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class ParseHolidaysService {
	
	private static String countryName;

	public static void main(String[] args) throws IOException {

		String[] christianHolidays = {
				"Epiphany",
				"Shrove Tuesday",
				"Ash Wednesday",
				"Laetare Sunday",
				"Palm Sunday",
				"Maundy Thursday",
				"Good Friday",
				"Holy Saturday",
				"Easter Monday",
				"Ascension Day",
				"Pentecost Sunday",
				"Whit Monday",
				"Corpus Christi",
				"Annunciation",
				"First Sunday in Advent",
				"Second Sunday in Advent",
				"Third Sunday in Advent",
				"Fourth Sunday in Advent",
				"Christmas Eve",
				"Christmas Day"};
		String[] missingHolidays = {
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1",
				"1"};
	
		// Paste the output from the API Query Builder here.
		// Be sure to set the attribute for the text file to UTF-8 and not ANSI!
		File inputFile = new File("C:/Users/EAC/Documents/timeanddate/Holiday QA Project/API Holiday Service/Countries/deUTF8.txt");
		File outputFile = new File("C:/Users/EAC/Documents/timeanddate/Holiday QA Project/API Holiday Service/Countries/deUTF8Output.txt");
		FileOutputStream fileOutputStream = new FileOutputStream(outputFile);
		BufferedWriter outFile = new BufferedWriter(new OutputStreamWriter(fileOutputStream));
		
		try {
		
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("holiday");
		
			int counter = 0;
			// Loop thru
			for (int x = 0; x < nList.getLength(); x++) {
				
				Node nNode = nList.item(x);
				
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					
					// spacer
					//System.out.println("--------------------------------");
					
					// id
					//System.out.println("ID: " 
					//		+ eElement
			        //          .getAttribute("id"));
					
					// country
					counter++;
					System.out.println(counter + ": " 
			                  + eElement
			                  .getElementsByTagName("country")
			                  .item(0)
			                  .getTextContent()
			                  + "\t"
			                  + eElement
			                  .getElementsByTagName("name")
			                  .item(0)
			                  .getTextContent()
			                  + "\t"
			                  + eElement
			                  .getElementsByTagName("type")
			                  .item(0)
			                  .getTextContent());

					if (countryName == null) {

						countryName = eElement
				                  .getElementsByTagName("country")
				                  .item(0)
				                  .getTextContent();
						
					}
					
					String holidayName = eElement
			                  .getElementsByTagName("name")
			                  .item(0)
			                  .getTextContent();

					// Look for the name in the 
					// array of holiday names.
					for (int i = 0; i < christianHolidays.length; i++) {
						
						if (christianHolidays[i].equals(holidayName)) {
							
							missingHolidays[i] = "0";
							break;
							
						}
						
					}
					
				}
				
			}
			
		} catch (Exception err1) {
			
			System.out.println("Error 1 ");
			err1.printStackTrace();
			
		}
		
		int outCounter = 0;
		System.out.println(" ");
		System.out.println("Missing holidays for " + countryName + ":");
		outFile.write("Missing holidays for " + countryName + ":");
		outFile.newLine();
		System.out.println("-----------------------------------------");
		// List the missing holidays
		for (int i = 0; i < missingHolidays.length; i++) {
			
			if (missingHolidays[i].equals("1")) {
				
				System.out.println(christianHolidays[i]);
				outFile.write(christianHolidays[i]);
				outFile.newLine();
				outCounter++;
				
			}
			
		}
		
		System.out.println("-----------------");
		System.out.println("Total: " + outCounter);
		outFile.write("Total: " + outCounter);
		outFile.newLine();
		System.out.println("-----------------");
		System.out.println("That's all folks!");
		outFile.close();
		
	}
	
}