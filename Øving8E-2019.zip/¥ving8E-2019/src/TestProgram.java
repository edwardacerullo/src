
/*
 * �ving8E, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

import javax.swing.JOptionPane;
import java.util.Arrays;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestProgram {

	public static void main(String[] args) {

		// Standing -- North, South, West -- a.k.a. the cheap seats
		System.out.println("Setup Staa Tribune North");
		Staa staaTribuneN = new Staa("Staa Tribune North", 25, 1000);
		System.out.println("Setup Staa Tribune South");
		Staa staaTribuneS = new Staa("Staa Tribune South", 50, 1000);
		System.out.println("Setup Staa Tribune West");
		Staa staaTribuneW = new Staa("Staa Tribune West", 100, 1000);
		// Sitting -- East
		System.out.println("Setup Sitte Tribune East");
		Sitte sitteTribuneE = new Sitte("Sitte Tribune East", 25, 1000, 20);
		// VIP -- East
		System.out.println("Setup VIP Tribune East");
		VIP vipTribuneE = new VIP("VIP Tribune East", 25, 1000, 10);
		// Put 'em together
		System.out.println("All together now!");
		Tribune[] tribuneInventory = { staaTribuneN, staaTribuneS, staaTribuneW, sitteTribuneE, vipTribuneE };
		System.out.println(tribuneInventory[0].toString());
		System.out.println(tribuneInventory[1].toString());
		System.out.println(tribuneInventory[2].toString());
		System.out.println(tribuneInventory[3].toString());
		System.out.println(tribuneInventory[4].toString());

		// Now, let's make some tickets!

		// Staa Tribune North:
		Billett[] InventoryListStaaN = staaTribuneN.kjopBilletter(2);
		for (Billett billett : InventoryListStaaN) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Staa Tribune South:
		Billett[] InventoryListStaaS = staaTribuneS.kjopBilletter(2);
		for (Billett billett : InventoryListStaaS) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Staa Tribune West:
		Billett[] InventoryListStaaW = staaTribuneW.kjopBilletter(2);
		for (Billett billett : InventoryListStaaW) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Sitt Tribune East
		Billett[] InventoryListSittE = sitteTribuneE.kjopBilletter(1);
		for (Billett billett : InventoryListSittE) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}
		
		// VIP Tribune East
		String[] case1 = { "Edward" };
		Billett[] InventoryListVIPE = vipTribuneE.kjopBilletter(case1);
		for (Billett billett : InventoryListVIPE) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}
		
		/*
		 * Oppgave E:
		 * 
		 * Vis hvordan vi sorterer Tribune-tabellen etter inntekt ved � bruke en
		 * metode i klassen Arrays. Show how we sort the Tribune table by income
		 * using a method in the class Arrays.
		 * 
		 */

	 	System.out.println("Unsorted");
		for (int i = 0; i < tribuneInventory.length; i++)

			System.out.println(tribuneInventory[i]);

		Arrays.sort(tribuneInventory);

		System.out.println("\nSorted by inntekt");

		for (int i = 0; i < tribuneInventory.length; i++)

			System.out.println(tribuneInventory[i]);
		
	/*
	 * Oppgave E:
	 * 
	 * 2. Lagre alle tribuneobjektene p� fil. Les dem inn fra fil igjen og skriv ut.
	 * 
	 */
		
		try {
			
			FileOutputStream fileOut = new FileOutputStream(new File("OppgaveE.txt"));
			ObjectOutputStream objectsOut = new ObjectOutputStream(fileOut);

			// Write each to the file
			objectsOut.writeObject(staaTribuneN);
			objectsOut.writeObject(staaTribuneS);
			objectsOut.writeObject(staaTribuneW);
			objectsOut.writeObject(sitteTribuneE);
			objectsOut.writeObject(vipTribuneE);

			objectsOut.close();
			fileOut.close();

			System.out.println("Writing the file...");
			FileInputStream fileIn = new FileInputStream(new File("OppgaveE.txt"));
			ObjectInputStream objectsIn = new ObjectInputStream(fileIn);

			// Read objects
			System.out.println("Reading the file...");
			Staa staaTribuneN1 = (Staa) objectsIn.readObject();
			Staa staaTribuneS1 = (Staa) objectsIn.readObject();
			Staa staaTribuneW1 = (Staa) objectsIn.readObject();
			Sitte sitteTribuneE1 = (Sitte) objectsIn.readObject();
			VIP vipTribuneE1 = (VIP) objectsIn.readObject();

			System.out.println(staaTribuneN1.toString());
			System.out.println(staaTribuneS1.toString());
			System.out.println(staaTribuneW1.toString());
			System.out.println(sitteTribuneE1.toString());
			System.out.println(vipTribuneE1.toString());

			objectsIn.close();
			fileIn.close();
			System.out.println("That's all Folks!");

		} catch (FileNotFoundException err1) {
			System.out.println("File not found");
			err1.printStackTrace();
		} catch (IOException err2) {
			System.out.println("Error initializing stream");
			err2.printStackTrace();
		} catch (ClassNotFoundException err3) {
			// TODO Auto-generated catch block
			err3.printStackTrace();
		}		
	
	}

}
