/*
 * �ving8D, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class VIP extends Sitte {
	
	// VIP = Tribune + Sitte + tilskuer
	private String[][] tilskuer;

	public VIP(String tribunenavn, int kapasitet, int pris, int antRaders) {
		super(tribunenavn, kapasitet, pris, antRaders);
		// TODO Auto-generated constructor stub
		tilskuer = new String[antRaders][getKapasitet() / antRaders];
	}
	
	// Part B: Add finnAntallSolgteBilletter
	public int finnAntallSolgteBilletter() {

		return super.finnAntallSolgteBilletter();

	}

	// Part B: Add finnInntekt
	public int finnInntekt() {

		return (getPris() * super.finnAntallSolgteBilletter());

	}

	// Part B: Gotta add this one too
	// TODO This looks fishy, but adding the super got rid of the error message!
	public int getPris() {

		return super.getPris();

	}

	// Part C: kjopBilletter number 1 -- number of tickets required
	public Billett[] kjopBilletter(int antBilletts, String[] navnList) {
		
        Billett[] billettListe = new Billett[antBilletts];
        
        if ((getKapasitet() - finnAntallSolgteBilletter()) >= navnList.length) {
        	
            for (int i = 0; i < navnList.length; i++) {
            	
                int[] ledigRad = getFreeRads(navnList.length);
                // Create a new one
                SitteplassBillett billetten = new SitteplassBillett(getTribunenavn(), getPris(), ledigRad[0], ledigRad[1]);
                billettListe[i] = billetten;
                // Set a new one
                tilskuer[ledigRad[0]][ledigRad[1]] = navnList[i];
            }
            
            return billettListe;
          
        }
        
        return null;
        
    }
	
	// Part C: kjopBilletter number 2 -- text strings as input and return a name list
	public Billett[] kjopBilletter(String[] navnList) {

		return kjopBilletter(navnList.length);

	}
	
	// Part C: 
	private int[] getFreeRads(int antallPlasser) {
		
        int[] ledigRad = new int[2];
        int startPlass = -1;
        
        for (int i = 0; i < tilskuer.length; i++) {
        	
            int counter = tilskuer[i].length;
            
            for (int ii = 0; ii < antallPlasser; ii++) {
            	
                if (tilskuer[i][ii] == null) {
                	
                    counter = counter - 1;
                    
                    if (startPlass == -1) {
                    	
                    	ledigRad[1] = startPlass;
                    	
                    }
                    
                }
                
            }
            
            // Adjust
            if (counter >= 0) {
            	
            	ledigRad[0] = i;
                return ledigRad;
                
            }
            
        }
        
        return null;
        
    }

}


