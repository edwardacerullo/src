/*
 * �ving8E, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 * 
 * 1)Now you shall program the ticket purchase. 
 *   This shall be done by creating two methods (in the Tribune class) that are both named kj�pBilletter(), 
 *   and shall return a table of ticket objects.
 *    
 * 2)The first method takes as parameters the number of tickets that are desired, 
 *   the other tasks as parameters a table of text strings (the names of those people who shall have the tickets).
 *   
 * 3)For all Tribune types, except the VIP tribunes, shall the second method give the same result as the first method, 
 *   except for the VIP tribune, shall the method return null (no one shall buy tickets for the VIP tribunes without giving a name).
 *   For all Tribune types check that if a person wants more tickets than can be sold
 *    
 * 4) For the sitting tribunes limit the number of tickets that are sold in an order, shall be in the same row.
 * 
 * 5) For the standing tribunes, is it just the total capacity and how many have been already sold that set the limits.
 * 
 * (Tips: Begge kj�pBilletter()-metodene skal eksistere i klassen Tribune.)
 * (Tips: Both of the kjopBilletter() methods shall exist in the Tribune class.)
 * 
 * 
 */

import java.io.Serializable;

public abstract class Tribune implements Serializable {

	// This is for Oppgave E
	private static final long serialVersionUID = 1L;
	// These are from the assignment
	private final String tribunenavn;
	private final int kapasitet;
	private final int pris;

	public Tribune(String tribunenavn, int kapasitet, int pris) {

		this.tribunenavn = tribunenavn;
		this.kapasitet = kapasitet;
		this.pris = pris;

	}

	// This is needed for VIP.java
	public int getKapasitet() {

		return kapasitet;

	}

	// This is for Tribune.java
	public String getTribunenavn() {

		return tribunenavn;

	}

	// This is also for Tribune.java
	public int getPris() {

		return pris;

	}

	// Part B: Add this
	public int finnAntallSolgteBilletter() {

		return 0; // TODO There has to be more to this!

	}

	// Part B: Add this
	public int finnInntekt() {

		// Inntekten er prisen multiplisert med antall solgte billetter.
		return (getPris() * finnAntallSolgteBilletter());

	}
	
	// Part D: Add toString
    public String toString() {
    	
        return "Namn: " + getTribunenavn() + "\n"
        		+ " Kapasitey: " + getKapasitet() + "\n"
        				+ " Ant solgt billetts: " + finnAntallSolgteBilletter() + "\n"
        						+ " Kroners inntek: " + finnInntekt();
        
    }
	
	
	
}