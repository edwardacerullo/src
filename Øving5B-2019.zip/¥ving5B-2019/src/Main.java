/*
 * 
 * �ving 5B
 * Spring, 2019
 * Edward Cerullo
 * 
 */

public class Main {
	
    public static void main(String[] args) throws Exception {
    	
        MySQLInquiry �5b = new MySQLInquiry();
        �5b.readTables();
        
    }

}