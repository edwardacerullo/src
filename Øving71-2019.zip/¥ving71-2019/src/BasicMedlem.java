/*
 * BasicMedlem.java
 * 17 March, 2019
 * Edward Cerullo
 * 
 */

import java.time.LocalDate;

/*
 *
 * BasicMedlem
 * 
 */

class BasicMedlem extends BonusMedlem {
	
	// Silver is 1.2, and Gold is 1.5
	private final int poengFaktor = 1;

	public BasicMedlem(int medlNr, Personalia pers, LocalDate localDate) {

		super(medlNr, pers, localDate);

	}

	public String toString() {

		return super.toString() + " og er BasicMedlem.";

	}

}