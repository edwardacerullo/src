/*
 * GullMedlem.java
 * 17 March, 2019
 * Edward Cerullo
 * 
 */

import java.time.LocalDate;

/*
 *
 * GullMedlem
 * 
 */

class GullMedlem extends BonusMedlem {

	// Silver is 1.2, and Gold is 1.5
	private final double poengFaktor = 1.5;

	public GullMedlem(int medlNr, Personalia pers, LocalDate dato2, int poeng) {

		super(medlNr, pers, dato2);

	}

	public void registrerPoeng(int poeng) {

		Double poengSolv = new Double(poeng * poengFaktor);
		poeng = poengSolv.intValue();

	}

	public String toString() {

		return super.toString() + " og er GullMedlem.";

	}

}