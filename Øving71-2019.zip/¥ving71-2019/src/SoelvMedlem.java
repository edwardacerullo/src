/*
 * SoelvMedlem.java
 * 17 March, 2019
 * Edward Cerullo
 * 
 */

import java.time.LocalDate;

/*
 *
 * SoelvMedlem
 * 
 */

class SoelvMedlem extends BonusMedlem {

	// Silver is 1.2, and Gold is 1.5
	private final double poengFaktor = 1.2;

	public SoelvMedlem(int medlNr, Personalia pers, LocalDate dato2, int poeng) {

		super(medlNr, pers, dato2);
		super.registrerPoeng(poeng);

	}

	public void registrerPoeng(int poeng) {

		Double poengSolv = new Double(poeng * poengFaktor);
		poeng = poengSolv.intValue();
		super.registrerPoeng(poeng);

	}

	public String toString() {

		return super.toString() + " og er S�lvMedlem.";

	}

}