
/*
 * Medlemsarkiv.java
 * 17 March, 2019
 * Edward Cerullo
 * 
 */

import java.util.*;
import java.time.LocalDate;

class Medlemsarkiv {

	private ArrayList<BonusMedlem> medlemmer = new ArrayList<BonusMedlem>();
	
	private final int SOLVMEDLEM = 50000 - 1;
	private final int GULLMEDLEM = 75000 - 1;

	private int finnLedignr() {

		Random random = new Random(medlemmer.size());
		int medlnr = random.nextInt();
		for (BonusMedlem medlem : medlemmer) {

			if (medlnr == medlem.getMedlnr()) {
				medlnr = random.nextInt();

			}

		}

		return medlnr;

	}

	// Get the Member Number
	public int getMedlemNummer(Personalia person) {

		for (BonusMedlem medlem : medlemmer) {

			if (medlem.getPers().equals(person))
				return medlem.getMedlnr();

		}

		return -1;

	}
	
	public int nyMedlem(Personalia pers, LocalDate innmeldt) {

		int medlnr = finnLedignr();
		System.out.println(medlnr);
		medlemmer.add(new BasicMedlem(Math.abs(medlnr), pers, innmeldt));
		return medlnr;

	}

	public boolean registrerPoeng(int medlnr, int poeng) {

		for (BonusMedlem medlem : medlemmer) {

			if (medlnr == medlem.getMedlnr()) {

				medlem.registrerPoeng(poeng);
				return true;

			}

		}

		return false;

	}

	public int getPoeng(int medlnr) {

		for (BonusMedlem medlem : medlemmer) {

			if (medlem.getMedlnr() == medlnr)
				return medlem.getPoeng();

		}

		return -1;

	}

	public void sjekkMedlemmer(LocalDate idag) {

		for (BonusMedlem medlem : medlemmer) {

			if (medlem instanceof BasicMedlem) {

				if (medlem.finnKvalPoeng(idag) > GULLMEDLEM) {

					medlemmer.set(medlemmer.indexOf(medlem), new GullMedlem(medlem.getMedlnr(), medlem.getPers(),
							medlem.getInnmeldtDato(), medlem.getPoeng()));

				}

				else if (medlem.finnKvalPoeng(idag) > SOLVMEDLEM) {

					medlemmer.set(medlemmer.indexOf(medlem), new SoelvMedlem(medlem.getMedlnr(), medlem.getPers(),
							medlem.getInnmeldtDato(), medlem.getPoeng()));

				}

			}

			else if (medlem instanceof SoelvMedlem && medlem.finnKvalPoeng(idag) > GULLMEDLEM) {

				medlemmer.set(medlemmer.indexOf(medlem), new GullMedlem(medlem.getMedlnr(), medlem.getPers(),
						medlem.getInnmeldtDato(), medlem.getPoeng()));

			}

		}

	}

	public String toString() {

		String tekst = "Medlemmer in arkive: \n";

		for (BonusMedlem medlem : medlemmer) {

			tekst += medlem + "\n";

		}

		return tekst + "\n in alt " + medlemmer.size() + " medlemmer.";

	}

}
