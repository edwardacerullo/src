/*
 * TestMedlemsarkiv.java
 * 17 March, 2019
 * Edward Cerullo
 * 
 */

/*
 * Lag en enkel testklient der spesielt metoden sjekkMedlemmer() blir pr�vd ut. 
 * Du kan finne det hensiktsmessig � lage flere metoder i klassen Medlemsarkiv for � f� testet tilstrekkelig. 
 * Hvis du trenger � skrive ut hvilken klasse et objekt tilh�rer, kan du bruke metoden getClass() i klassen Object.
 * Create a simple test client that specifies the method sjekkMedlemmer is tried out. 
 * You can find this appropriate to make more methods in class Medlemsarkiv for to test the adequately. 
 * If you need to write out which class an object uses, you can use the method getClass() in class Object. 
 */

import java.time.LocalDate;

class TestMedlemsakiv {

	public static void main(String[] args) {

		// Create a new archive
		Medlemsarkiv arkiv = new Medlemsarkiv();

		// Set the dates -- now, this year, next year
		LocalDate dateToday = LocalDate.parse("2019-03-17");
		LocalDate dateTY = LocalDate.parse("2019-04-17");
		LocalDate dateNY = LocalDate.parse("2019-03-18");
		
		Personalia Bertha = new Personalia("Bronk-Harris", "Bertha", "Bertha@BattleCreekOnline.com", "bertha");
		Personalia Albert = new Personalia("Harris", "Albert", "Albert@BattleCreekOnline.com", "albert");
		Personalia Mildred = new Personalia("Harris-Troia", "Mildred", "Mildred@BattleCreekOnline.com", "mildred");
		Personalia June = new Personalia("Harris", "June", "June@BattleCreekOnline.com", "june");
		Personalia Fanny = new Personalia("Harris-Wilfred", "Fanny", "Fanny@BattleCreekOnline.com", "fanny");
		Personalia WandaSue = new Personalia("Wilfred", "WandaSue", "WandaSue@BattleCreekOnline.com", "wandasue");

		int medlemsNummerBertha = arkiv.nyMedlem(Bertha, dateToday);
		int medlemsNummerAlbert = arkiv.nyMedlem(Albert, dateToday);
		int medlemsNummerMildred = arkiv.nyMedlem(Mildred, dateToday);
		int medlemsNummerJune = arkiv.nyMedlem(June, dateToday);
		int medlemsNummerFanny = arkiv.nyMedlem(Fanny, dateToday);
		int medlemsNummerWandaSue = arkiv.nyMedlem(WandaSue, dateToday);

		// Before
		System.out.println(arkiv);

		System.out.println("\n Round 1 points: \n");
		arkiv.registrerPoeng(medlemsNummerBertha, 1000);
		arkiv.registrerPoeng(medlemsNummerAlbert, 2000);
		arkiv.registrerPoeng(medlemsNummerMildred, 3000);
		arkiv.registrerPoeng(medlemsNummerJune, 4000);
		arkiv.registrerPoeng(medlemsNummerFanny, 5000);
		arkiv.registrerPoeng(medlemsNummerWandaSue, 10000);

		// After Round 1 - pre
		System.out.println(arkiv);

		System.out.println("\n Running sjekkMedlemmer for less than a year: \n");
		arkiv.sjekkMedlemmer(dateTY);

		// After Round 1 - post
		System.out.println(arkiv);

		System.out.println("\n Round 2 points: \n");

		arkiv.registrerPoeng(medlemsNummerBertha, 11000);
		arkiv.registrerPoeng(medlemsNummerAlbert, 12000);
		arkiv.registrerPoeng(medlemsNummerMildred, 13000);
		arkiv.registrerPoeng(medlemsNummerJune, 14000);
		arkiv.registrerPoeng(medlemsNummerFanny, 15000);
		arkiv.registrerPoeng(medlemsNummerWandaSue, 110000);

		// After Round 2
		System.out.println(arkiv);

		System.out.println("\n Running sjekkMedlemmer for more than a year: \n");
		arkiv.sjekkMedlemmer(dateNY);
		System.out.println(arkiv);

		System.out.println("\n Running sjekkMedlemmer for less than a year: \n");
		arkiv.sjekkMedlemmer(dateTY);
		System.out.println(arkiv);

	}

}