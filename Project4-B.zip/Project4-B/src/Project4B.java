import java.util.*;
import java.io.*;

public final class Project4B {

	public static void main(String[] args) {

		String filenavn1 = "C:/Temp/resultater.txt";
		String filenavn2 = "C:/Temp/datafile.ser";

		try {

			// Setup the array
			ArrayList<Resultat> resultater = new ArrayList<Resultat>();

			FileReader inputFile = new FileReader(filenavn1);
			BufferedReader input = new BufferedReader(inputFile);

			try {

				String inputLine = input.readLine();

				while (inputLine != null) {

					// Strip out the fields
					StringTokenizer orderedStringTokenizer = new StringTokenizer(inputLine,
							",");
					ArrayList<String> orderedArrayList = new ArrayList<String>();

					for (int i = 0; i < 3; i++) {
						
						orderedArrayList.add(new String(orderedStringTokenizer.nextToken().trim()));

					}

					/*
					 * This is what I'm looking for:
					 *  
					 * private final String fagnr
					 * private final String fagnavn
					 * private int antStudiepoeng
					 * private char[] karakterer
					 * 
					 */

					// Get the three fields...
					String fagnr = orderedArrayList.get(0);
					String fagnavn = orderedArrayList.get(1);
					int antStudiepoeng = Integer.parseInt(orderedArrayList.get(2));

					// Then the grades, one by one
					char[] karakterer = new char[orderedStringTokenizer.countTokens()];
					for (int i = 0; i < karakterer.length; i++) {

						karakterer[i] = orderedStringTokenizer.nextToken().trim().charAt(0);

					}

					// Write to the output file
					resultater.add(new Resultat(fagnr, fagnavn, antStudiepoeng,
							karakterer));
					inputLine = input.readLine();

				}

				input.close();

				// Loop thru and print the resultat
				for (Resultat resultat : resultater) {

					System.out.println(resultat);

				}

				// TODO: Make this a separate method
				FileOutputStream outputFile = new FileOutputStream(
						filenavn2);
				ObjectOutputStream outputResults = new ObjectOutputStream(
						outputFile);

				for (Resultat resultat : resultater) {

					outputResults.writeObject(resultat);

				}

				outputResults.close();

				// TODO: Make this also a separate method
				ArrayList<Resultat> resultaterBravo = new ArrayList<Resultat>();

				FileInputStream inputFileBravo = new FileInputStream(filenavn2);
				ObjectInputStream readResult = new ObjectInputStream(inputFileBravo);

				try {

					Resultat result = (Resultat) readResult.readObject();
					while (result != null) {

						resultaterBravo.add(result);
						result = (Resultat) readResult.readObject();

					}

				} catch (Exception err3) {

					System.out.println("IO Error on Bravo add: " + err3);

				}

				// TODO: This too should be a separate method
				System.out.println("\n Bravo Results:");
			    for(Resultat resultat : resultaterBravo) {
			    	
			      System.out.println(resultat);
			      
			    }
				
			    readResult.close();
			    
			    
			} catch (IOException err2) {

				System.out.println("IO Error on readLine: " + err2);

			}

		} catch (FileNotFoundException err1) {

			System.out.println("IO Error on fileReader: " + err1);

		}

	}

}
