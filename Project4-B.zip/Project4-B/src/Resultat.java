
/*
 * Oppgave 4, part A
 * 
 * Make a:
 * 
 * - class called Resultat
 * - constructor for the Resultat class
 * - a toString() method to group them together
 *
 *  
 * Oppgave 4, Part B
 * 
 *   Used in conjunction with Project4B.java
 *  
 */

public class Resultat {

	private final String fagnr;
	private final String fagnavn;
	private int antStudiepoeng;
	private char[] karakterer;	
	
	public Resultat (String fagnr, String fagnavn, int antStudiepoeng, char[] karakterer) {
		
		this.fagnr = fagnr;
		this.fagnavn = fagnavn;
		this.antStudiepoeng = antStudiepoeng;
		this.karakterer = karakterer;
		
	}
	
	public String toString() {
		
		// Change the array into a string one character at a time
		String karaktererString = "";
		for (char karaktererChar : karakterer) {
			
			karaktererString += karaktererChar + ", ";
			
		}
		
		return fagnr + ", " + fagnavn + ", " + antStudiepoeng + ", " + karaktererString;
	}
	
}
