package no.cerullo.mysql.first;

import java.sql.*;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class MySQLAccess {

 	public void readDataBase() throws Exception {
 
 		System.out.println("Defining the data source...");
 		MysqlDataSource dataSource = new MysqlDataSource();
 		dataSource.setUrl("jdbc:mysql://mur.timeanddate.net/QA");
 		dataSource.setUser("eac");
 		dataSource.setPassword("Time0123&");
 		
 		System.out.println("Connecting...");
 		Connection conn = dataSource.getConnection();
 		
 		// Initialize the statement variable
 		Statement stmt = null;
 	    String query = "CREATE TABLE comments1 (id INT NOT NULL AUTO_INCREMENT, MYUSER VARCHAR(30) NOT NULL, EMAIL VARCHAR(30), WEBPAGE VARCHAR(100) NOT NULL, DATUM DATE NOT NULL, SUMMARY VARCHAR(40) NOT NULL, COMMENTS VARCHAR(400) NOT NULL, PRIMARY KEY (ID));";
 	    
 	    try {
 	    	
 	    	stmt = conn.createStatement();
 	    	System.out.println("Executing the SQL...");
 	    	int stat = stmt.executeUpdate(query);
 	    	System.out.println("Status = " + stat);
 	    
 	    } catch (SQLException e ) {
 	        // TODO
 	    } finally {
 	        if (stmt != null) { stmt.close(); }
 	    }
 	     		
 		System.out.println("Closing statement...");
 		stmt.close();
 		System.out.println("Closing connection...");
 		conn.close(); 		
 		
    }

}