import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;

public class �ving10A extends JFrame {
	
	/**
	 * Eclipse wants to put this in.
	 */
	private static final long serialVersionUID = 1L;
	
	public static void main (String[] args) {
	
		System.out.println("This is the main.");
		
		�ving10A();
		
		System.out.println("This is the return.");
		return;
		
		}

	/*
	 * This is the guts.
	 */
	private static void �ving10A() {

		System.out.println("This is the start.");
		// First, the JPanel -- Don't know what I need this for.
		// TFM says so, tho.

		JPanel panel1 = new JPanel();

		// Next, the frame.
		JFrame frame1 = new JFrame("Fun With Fonts!");

		// Next, a label field.
		JLabel label1 = new JLabel();
		label1.setText("Please enter some text:");
		label1.setFont(new Font("Arial", Font.PLAIN, 24));
		label1.setForeground(Color.ORANGE);
		label1.setBounds(100, 200, 300, 100);
		frame1.add(label1);

		// Then, a text field.
		JTextField text1 = new JTextField();
		text1.setBounds(100, 400, 300, 100);
		text1.setFont(new Font("Arial", Font.PLAIN, 24));
		frame1.add(text1);

		// And finally, buttons.
		JButton button1, button2, button3, button4;

		button1 = new JButton("SansSerif");
		button1.setBounds(100, 600, 140, 40);
		button1.setFont(new Font("SansSerif", Font.PLAIN, 24));
		button1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e1) {
				
				switchTheFont(button1, text1);
			}
			
		});
		frame1.add(button1);

		button2 = new JButton("Serif");
		button2.setBounds(250, 600, 140, 40);
		button2.setFont(new Font("Serif", Font.PLAIN, 24));
		button2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e2) {
				
				switchTheFont(button2, text1);
			}
			
		});

		frame1.add(button2);

		button3 = new JButton("Monospaced");
		button3.setBounds(400, 600, 140, 40);
		button3.setFont(new Font("Monospaced", Font.PLAIN, 24));
		button3.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e3) {
				
				switchTheFont(button3, text1);
			}
			
		});

		frame1.add(button3);

		button4 = new JButton("Dialog");
		button4.setBounds(550, 600, 140, 40);
		button4.setFont(new Font("Dialog", Font.PLAIN, 24));
		button4.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e4) {
				
				switchTheFont(button4, text1);
			}
			
		});

		frame1.add(button4);

		// Finish up.
		frame1.setLayout(null);
		frame1.setSize(1000, 1000);
		frame1.setVisible(true);
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		System.out.println("This is the end.");
	}
	
	private static void switchTheFont(JButton buttonX, JTextField text1) {
		
		System.out.println("This is the SWITCH. What have we:");
		System.out.println(buttonX.getFont().getFontName());
		/*
		 * Set the values.
		 * Add some color, to make the output more interesting.
		 */
		switch(buttonX.getFont().getFontName()) {
		
			case "SansSerif.plain":
				buttonX.setFont(new Font("sanserif", Font.PLAIN, 12));
				buttonX.setForeground(Color.RED);
				text1.setFont(new Font("sanserif", Font.PLAIN, 12));
				text1.setForeground(Color.RED);
				break;
			case "Serif.plain":
				buttonX.setFont(new Font("serif", Font.PLAIN, 12));
				buttonX.setForeground(Color.GREEN);
				text1.setFont(new Font("serif", Font.PLAIN, 12));
				text1.setForeground(Color.GREEN);
				break;
			case "Monospaced.plain":
				buttonX.setFont(new Font("monospaced", Font.PLAIN, 12));
				buttonX.setForeground(Color.BLUE);
				text1.setFont(new Font("monospaced", Font.PLAIN, 12));
				text1.setForeground(Color.BLUE);
				break;
			case "Dialog.plain":
				buttonX.setFont(new Font("dialog", Font.PLAIN, 12));
				buttonX.setForeground(Color.YELLOW);
				text1.setFont(new Font("dialog", Font.PLAIN, 12));
				text1.setForeground(Color.YELLOW);
				break;
				
		}
		
	}

}