import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
/**
 * @author Edward Cerullo
 * @version 1.0
 * @category flash_cards_dtl table in QA
 */

public class DropTable {
 
    /**
     * Drop a table in the test database
     *
     */
    public static void main(String[] args) {
    	
    	// First, load the driver
    	try {
    		
    		Class.forName("com.mysql.jdbc.Driver").newInstance();
    		System.out.println("Driver is loaded...");
    		
    	} catch (Exception errLoad) {
    		
    		System.out.println("Error on load...");
            System.out.println(errLoad.getMessage());
    		
    	}
    	
        // Next, get a connection
    	Connection connection = null;
    	try {
    		
    		connection = DriverManager.getConnection("jdbc:mysql://mur.timeanddate.net?user=eac&password=Java0123&&useSSL=false");
    		System.out.println("Connection is complete...");
    		
        } catch (SQLException errConnection) {
        	
        	System.out.println("Error on connection...");
            System.out.println("SQL Exception: " + errConnection.getMessage());
            System.out.println("SQL State: " + errConnection.getSQLState());
            System.out.println("SQL Error Code: " + errConnection.getErrorCode());
            
        }
    		
        // SQL USE statement
    	Statement statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "USE QA";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement USE is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on USE statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}

        // SQL DROP statement
    	statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "DROP TABLE flash_cards_dtl";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement DROP is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on DROP statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
        System.out.println("That's all, folks!");
        
    }
 
}