import javax.swing.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class CalcEasterCalendar extends JPanel{

	/**
	 * Added for some reason...
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {

		JFrame frame1 = new JFrame("Easter Date");

		String easterDateString = JOptionPane.showInputDialog(frame1, "Please enter the date for Easter MM/DD/YYYY: ");

		String expectedPattern = "MM/dd/yyyy";
		SimpleDateFormat formatter = new SimpleDateFormat(expectedPattern);

		try {

			Date simpleDateForEaster = formatter.parse(easterDateString);
			System.out.println("Easter is: " + simpleDateForEaster);
			
			// if the parse is good, then format the date as a LocalDate
			DateTimeFormatter mmddyyFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
			LocalDate easterDate = LocalDate.parse(easterDateString, mmddyyFormat);
			// Shrove Tuesday
			LocalDate shroveTuesday = easterDate.minus(Period.ofDays(47));
			System.out.println("Shrove Tuesday (Mardi Gras) is: " + shroveTuesday);
			// Ash Wednesday
			LocalDate ashWednesday = easterDate.minus(Period.ofDays(46));
			System.out.println("Ash Wednesday is:               " + ashWednesday);
			// Laetare Sunday
			LocalDate laetareSunday = easterDate.minus(Period.ofWeeks(3));
			System.out.println("Laetare Sunday is:              " + laetareSunday);
			// Palm Sunday
			LocalDate palmSunday = easterDate.minus(Period.ofWeeks(1));
			System.out.println("Palm Sunday is:                 " + palmSunday);
			// Maundy Thursday
			LocalDate maudyThursday = easterDate.minus(Period.ofDays(3));
			System.out.println("Maundy Thursday is:             " + maudyThursday);
			// Good Friday
			LocalDate goodFriday = easterDate.minus(Period.ofDays(2));
			System.out.println("Good Friday is:                 " + goodFriday);
			// Easter Monday
			LocalDate easterMonday = easterDate.plus(Period.ofDays(1));
			System.out.println("Easter Monday is:               " + easterMonday);
			// Jesus Jumping Day
			LocalDate ascensionDay = easterDate.plus(Period.ofDays(39));
			System.out.println("Ascension of Jesus is:          " + ascensionDay);
			// The Pentecost
			LocalDate pentecostSunday = easterDate.plus(Period.ofWeeks(7));
			System.out.println("Pentecost Sunday is:            " + pentecostSunday);
			// Whit Monday
			LocalDate whitMonday = easterDate.plus(Period.ofDays(50));
			System.out.println("Whit Monday is:                 " + whitMonday);

			JFrame frame2 = new JFrame("Dates based on Easter");
			JOptionPane.showMessageDialog(frame2, "Easter is: " + simpleDateForEaster + "\n"
						+ "Shrove Tuesday (Mardi Gras) is: " + shroveTuesday + "\n"
						+ "Ash Wednesday is:               " + ashWednesday + "\n"
			     		+ "Laetare Sunday is:              " + laetareSunday + "\n"
			     		+ "Palm Sunday is:                 " + palmSunday + "\n"
			     		+ "Maundy Thursday is:             " + maudyThursday + "\n"
			     		+ "Good Friday is:                 " + goodFriday + "\n"
			     		+ "Easter Monday is:               " + easterMonday + "\n"
			     		+ "Ascension of Jesus is:          " + ascensionDay + "\n"
			     		+ "Pentecost Sunday is:            " + pentecostSunday + "\n"
			     		+ "Whit Monday is:                 " + whitMonday);
			
		} catch (DateTimeParseException | ParseException errDate) {
			
			System.out.println("Can not parse date for Easter. " + errDate);
			errDate.printStackTrace();

		}

		System.out.println("That's All Folks!");
		System.exit(0);

	}

}