/** @brief Read an Excel Worksheet

Commands used:

- getContents() 
- getType(), including CellType.LABEL and CellType.NUMBER
- getColumns
- getRows
- getWorkbook
- getCell, with column first then row.

The first row is a heading. 
The first column is the test sequence number.

Update the setInputFile 
       and setOutputURL as needed.

 This is the format of the request:
 
 Sequence number and URL only

	  
 @author Edward Cerullo, Time and Date
 @date September 2021

**/

import java.io.File;
import java.io.IOException;

import javax.swing.JOptionPane;

import org.eclipse.swt.program.*;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {

	public static void main(String[] args) throws IOException {

		System.out.println("Starting to read the spreadsheet with the pages for Jira PDB-404...");

		ReadExcel test = new ReadExcel();
		test.setInputFile("C:/Users/EAC/Documents/Jiras/PDB-404/PDB-404.xls");
		// 
		test.setOutputURL("");
		test.read();

		System.out.println("Finished.");
	}

	private String inputFile;

	public void setInputFile(String inputFile) {

		this.inputFile = inputFile;

	}

	private String outputURL;

	public void setOutputURL(String outputURL) {

		this.outputURL = outputURL;

	}

	public void read() throws IOException {

		File inputWorkbook = new File(inputFile);

		Workbook wb;

		try {

			wb = Workbook.getWorkbook(inputWorkbook);

			// Get the first sheet
			Sheet sheet = wb.getSheet(0);
			
			String[] pageName = new String[sheet.getColumns() - 1];
			String[] fieldLabel = new String[sheet.getColumns() - 1];

			// Loop through the columns and rows

			System.out.println("Cols " + sheet.getColumns() + " Rows " + sheet.getRows());
			int counter = 0;
			
			for (int x = 0; x < sheet.getRows(); x = x + 1) {

				for (int y = 0; y < sheet.getColumns(); y = y + 1) {

					Cell cell = sheet.getCell(y, x);


					// Start at Row 2.
					// Start at column B.

					// 1st Row -- Label
					if (x == 0) {

						// 1st column
						if (y == 0) {

							fieldLabel[y - 1] = cell.getContents();
							
						} else {

							pageName[y - 1] = cell.getContents();

						}

					} // Headings

					// Get the test number or the value to be tested.
					// Ignore the first five header lines.
					String testNumber = ""; // This is used. Eclipse cries & nags too much.
					if (x > 0) {

						if (y == 0) {

							// Store the test sequence number
							testNumber = cell.getContents();


						} // test number or value

					}

					// Exclude the headings
					if ((y == sheet.getColumns() - 1) && (x > 0)) {

						// Heading
						// System.out.println("Test Number " + testNumber + "
						// Setup the URL string
						String outputURLComplete = "xxx";
						for (int i = 0; i < sheet.getColumns() - 1; i = i + 1) {

						}

						counter = counter + 1;
						System.out.println(counter + ": " + outputURLComplete);
						// And launch a browser
						JOptionPane.showConfirmDialog(null,
								"This doesn't do anything but allow me to look at the test.", "Please choose one -- which one doesn't matter!", JOptionPane.YES_NO_OPTION);
						Program.launch(outputURLComplete);

					}

				} // y loop

			} // x loop

			return;

		} catch (BiffException e) {

			e.printStackTrace();

		}

	}

}