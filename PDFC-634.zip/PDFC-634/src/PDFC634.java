import java.net.*;
import java.util.Map;
import java.io.*;

/*
 * Check a PDF Calendar
 *  
 * If the .pdf file size is too small, 
 * it was not created properly.
 * 
 */

public class PDFC634 {
	
	public static void main(String[] args) throws IOException {

		// URL fields.
		QueryBuilder.setBaseUrl("https://www.timeanddate.com/scripts/calpreview.php");
		QueryBuilder.setFullUrl("");
		// Parameter fields.
		QueryBuilder.setColumnColor1("ef0471");
		QueryBuilder.setColumnColor2("1397e7");
		QueryBuilder.setColumnMode("1");
		QueryBuilder.setCountry1("18");
		QueryBuilder.setCountry2("18");
		QueryBuilder.setPaperSize("4");
		QueryBuilder.setCountryAndState("0");
		QueryBuilder.setFirstDayOfWeek("0");
		QueryBuilder.setFontSize("0");
		QueryBuilder.setHolidayNewPage("0");
		QueryBuilder.setHolidays("4194329");
		QueryBuilder.setLanguage("en");
		QueryBuilder.setStartingMonth("11");
		QueryBuilder.setMoonPhase("1");
		QueryBuilder.setOrientation("1");
		QueryBuilder.setSite("1");
		QueryBuilder.setTypeOfCalendar("3");
		QueryBuilder.setVersionOfCalendar("1");
		QueryBuilder.setWeekNumber("1");
		QueryBuilder.setStartingYear("2019");
		QueryBuilder.setNumberOfYears("1");

		/*
		 * Pass the parameterList HashMap and 
		 * return the fullRequest StringBuilder.
		 */
		buildUrl();

		URL oracle = new URL(QueryBuilder.fullUrl);
		URLConnection conn = oracle.openConnection();
		long completeFileSize = conn.getContentLength();

		setReturnCode(completeFileSize);

	} // main

	/*
	 * Build the URL
	 */
	
	private static void buildUrl() {
	
		StringBuilder fullRequest = new StringBuilder(QueryBuilder.baseUrl + "?");
		for (Map.Entry<String, String> entry : QueryBuilder.parameterList.entrySet()) {

			fullRequest.append(entry.getKey() + "=" + entry.getValue() + "&");

		}

		// Convert to String
		QueryBuilder.fullUrl = fullRequest.toString();
	
	} // buildUrl
	
	/*
	 * Set the return code based 
	 * on the size of the returned file size.
	 */
	private static int setReturnCode(long completeFileSize) {

		if (completeFileSize > 10000) {

			//System.out.println("Good");
			return 0; // Good

		} else {

			//System.out.println("Bad");
			return 1; // Houston. We've had a problem.

		}

	} // setReturnCode

} // PDFC634 class