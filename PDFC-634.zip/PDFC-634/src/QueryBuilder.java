import java.util.HashMap;

/*
 * Build the query to
 * check a PDF Calendar. 
 * 
 */

public class QueryBuilder {

	static String baseUrl;
	static String fullUrl;
	
	// Set the base URL
	public static void setBaseUrl(String baseUrlNew) {
		QueryBuilder.baseUrl = baseUrlNew;
	}
	
	// Set the full URL
	public static void setFullUrl(String fullUrlNew) {
		QueryBuilder.fullUrl = fullUrlNew;
	}

	// HashMap for the calendar parameter fields
	static HashMap<String, String> parameterList = new HashMap<String, String>();

	// Set the Parameter List strings
	public static void setColumnColor1(String ccol1New) {
		parameterList.put("ccol1", ccol1New);
	}

	public static void setColumnColor2(String ccol2New) {
		parameterList.put("ccol2", ccol2New);
	}

	public static void setColumnMode(String cmodeNew) {
		parameterList.put("cmode", cmodeNew);
	}

	public static void setCountry1(String country1New) {
		parameterList.put("country", country1New);
	}

	public static void setCountry2(String country2New) {
		parameterList.put("_country", country2New);
	}

	public static void setPaperSize(String cpaNew) {
		parameterList.put("cpa", cpaNew);
	}

	public static void setCountryAndState(String cstNew) {
		parameterList.put("cst", cstNew);
	}

	public static void setFirstDayOfWeek(String fdowNew) {
		parameterList.put("fdow", fdowNew);
	}

	public static void setFontSize(String fszNew) {
		parameterList.put("fsz", fszNew);
	}

	public static void setHolidayNewPage(String hnpNew) {
		parameterList.put("hnp", hnpNew);
	}

	public static void setHolidays(String holNew) {
		parameterList.put("hol", holNew);
	}

	public static void setLanguage(String langNew) {
		parameterList.put("lang", langNew);
	}

	public static void setStartingMonth(String monthNew) {
		parameterList.put("month", monthNew);
	}

	public static void setMoonPhase(String mphaseNew) {
		parameterList.put("mphase", mphaseNew);
	}

	public static void setOrientation(String oriNew) {
		parameterList.put("ori", oriNew);
	}

	public static void setSite(String siteNew) {
		parameterList.put("site", siteNew);
	}

	public static void setTypeOfCalendar(String typNew) {
		parameterList.put("typ", typNew);
	}

	public static void setVersionOfCalendar(String tplNew) {
		parameterList.put("tpl", tplNew);
	}

	public static void setWeekNumber(String wnoNew) {
		parameterList.put("wno", wnoNew);
	}

	public static void setStartingYear(String yearNew) {
		parameterList.put("year", yearNew);
	}

	public static void setNumberOfYears(String yearsNew) {
		parameterList.put("years", yearsNew);
	}

} // QueryBuilder class