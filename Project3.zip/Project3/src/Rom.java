import java.util.ArrayList;

/*
 * 
 * Class: Rom -- for the rooms
 * 
 */

class Rom {

	private int romNummer;
	private int plassCapacity;

	private ArrayList<Reservasjon> reservasjoner = new ArrayList<Reservasjon>();

	public Rom(int romNummer, int plassCapacity) {

		this.romNummer = romNummer;
		this.plassCapacity = plassCapacity;

	}

	/*
	 * For the Room Number
	 */
	public int getRomNummer() {

		return romNummer;
	}

	/*
	 * For the Place Capacity
	 */

	public int getPlassCapacity() {

		return plassCapacity;

	}

	/*
	 * Reserve the rooms here
	 */

	public boolean reserverRom(Reservasjon reservasjonen, int antPers) {

		for (int i = 0; i < reservasjoner.size(); i++) {

			if (reservasjoner.get(i).overlapp(reservasjonen.getFraTid(),
					reservasjonen.getTilTid())) {

				return false;

			}

		}

		reservasjoner.add(reservasjonen);
		return true;
	}

	/*
	 * Print the report
	 */

	@Override
	public String toString() {

		String printLine = "Rom Nummer " + romNummer + " med capacity "
				+ plassCapacity + " plassene. \nReservasjoner: \n";

		for (Reservasjon tid : reservasjoner) {

			printLine += "F: " + tid.getFraTid() + "   T: " + tid.getTilTid()
					+ "\n";

		}

		return printLine;

	}

	/*
	 * Test Rom
	 */

	public static void main(String[] args) {

		Rom rom1 = new Rom(1, 2);
		Rom rom2 = new Rom(2, 4);
		Rom rom3 = new Rom(3, 3);
		Rom rom4 = new Rom(4, 5);
		Rom rom5 = new Rom(5, 2);
		Rom rom6 = new Rom(6, 4);
		Rom rom7 = new Rom(7, 5);
		Rom rom8 = new Rom(8, 5);

		System.out.println("= Room Report =");
		System.out.println(rom1.toString());
		System.out.println(rom2.toString());
		System.out.println(rom3.toString());
		System.out.println(rom4.toString());
		System.out.println(rom5.toString());
		System.out.println(rom6.toString());
		System.out.println(rom7.toString());
		System.out.println(rom8.toString());

	}

}