/*
 * Conference Center
 */

import java.util.*;

class KonferanseSenter {

	private ArrayList<Rom> roms = new ArrayList<Rom>();
	
	/*
	 * Option 1 -- Reserve a room
	 */
	
	public int reserverRom(Reservasjon reservasjonen, int antPers) {

		for (int i = 0; i < roms.size(); i++) {
			
			if (roms.get(i).getPlassCapacity() >= antPers) {
				
				if (roms.get(i).reserverRom(reservasjonen, antPers)) {
					
					return roms.get(i).getRomNummer();
				}
				
			} else {
				
				System.out.println("Ingen nok capacity i rom " + i + "!");
				
			}
			
		}
		
		return 0;
		
	}

	/* 
	 * Option 2 -- Register a room in the inventory of rooms
	 */
	
	public boolean registrerRom(int romNummer, int antPerson){
	
		for (int i = 0; i < roms.size(); i++) {
			
			if(roms.get(i).getRomNummer() == romNummer) {

				return false;
				
			}
		}
		
		roms.add(new Rom(romNummer, antPerson));
		return true;
	}
	
	/*
	 * Option 3 -- Find the number of rooms in total and the res
	 */
	
	public int finnAntRom() {
		
		return roms.size();
		
	}
	
	public String finnReservasjoner() {
		
		String tekst = null;
		tekst = "\n"; // Start with a line feed
		
		for(int i = 0; i < roms.size(); i++) {
			
			tekst += "Rom nummer " + roms.get(i).getRomNummer() + "\n";
			
		}
		
		return tekst;
		
	}
	
	/*
	 * Option 4
	 */
	
	public Rom finnRomViaIndeks(int indeks) {
		
		if(indeks >= roms.size()) {
			
			return null;
			
		} else {
			
			return roms.get(indeks);
			
		}
		
	}
	
	/*
	 * Option 5
	 */
	
	public Rom finnRomViaNummer(int romnr) {
		
		Rom rom1 = null;
		
		for (int i = 0; i < roms.size(); i++) {
			
			if (roms.get(i).getRomNummer() == romnr) {
				
				rom1 = roms.get(i);
				
			}
			
		}
		
		return rom1;
	}
	
}