/*
 * �ving8B, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class Sitte extends Tribune {

	// Sitte = Tribune + antOpptatt
	private int [] antOpptatt;  // tabellst�rrelse: antall rader
	
	public Sitte(String tribunenavn, int kapasitet, int pris, int antRadars) {
		super(tribunenavn, kapasitet, pris);
		// TODO Auto-generated constructor stub
		antOpptatt = new int[antRadars];
	}

	// Part B: Add finnAntallSolgteBilletter
	public int finnAntallSolgteBilletter() {

		return super.finnAntallSolgteBilletter();

	}

	// Part B: Add finnInntekt
	public int finnInntekt() {

		return (getPris() * super.finnAntallSolgteBilletter());

	}

	// Part B: Gotta add this one too
	// TODO This looks fishy, but adding the super got rid of the error message!
	public int getPris() {

		return super.getPris();

	}
	
}