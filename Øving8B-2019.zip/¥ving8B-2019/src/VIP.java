/*
 * �ving8B, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class VIP extends Sitte {
	
	// VIP = Tribune + Sitte + tilskuer
	private String[][] tilskuer;

	public VIP(String tribunenavn, int kapasitet, int pris, int antRaders) {
		super(tribunenavn, kapasitet, pris, antRaders);
		// TODO Auto-generated constructor stub
		tilskuer = new String[antRaders][getKapasitet() / antRaders];
	}
	
	// Part B: Add finnAntallSolgteBilletter
	public int finnAntallSolgteBilletter() {

		return super.finnAntallSolgteBilletter();

	}

	// Part B: Add finnInntekt
	public int finnInntekt() {

		return (getPris() * super.finnAntallSolgteBilletter());

	}

	// Part B: Gotta add this one too
	// TODO This looks fishy, but adding the super got rid of the error message!
	public int getPris() {

		return super.getPris();

	}
	
}