/*
 * �ving8B, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public abstract class Tribune {

	// * These are from the assignment
	private final String tribunenavn;
	private final int kapasitet;
	private final int pris;

	public Tribune(String tribunenavn, int kapasitet, int pris) {

		this.tribunenavn = tribunenavn;
		this.kapasitet = kapasitet;
		this.pris = pris;

	}

	// This is needed for VIP.java
	public int getKapasitet() {
		
		return kapasitet;
		
	}

	
	// This is for Tribune.java
	public String getTrubunenavn() {
		
		return tribunenavn;
		
	}
	
	// This is also for Tribune.java
	public int getPris() {
		
		return pris;
		
	}

	// Part B: Add this
	public int finnAntallSolgteBilletter() {
		
		return 0; // TODO There has to be more to this! 
		
	}
	
	// Part B: Add this
	public int finnInntekt() {
		
		// Inntekten er prisen multiplisert med antall solgte billetter.
		return (getPris() * finnAntallSolgteBilletter());
		
	}
	
}