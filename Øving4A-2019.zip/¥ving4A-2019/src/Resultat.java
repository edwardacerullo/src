
/*
 * Oppgave 4, part A
 * Java IFUD1033, Spring 2019
 * 
 * Create a:
 * 
 * - class called Resultat;
 * - constructor for the Resultat class; and,
 * - toString() method to group them together.
 *  
 */

public class Resultat {

	private final String fagnr;
	private final String fagnavn;
	private int antStudiepoeng;
	private char[] kharakterer;

	public Resultat(String fagnr, String fagnavn, int antStudiepoeng, char[] kharakterer) {

		this.fagnr = fagnr;
		this.fagnavn = fagnavn;
		this.antStudiepoeng = antStudiepoeng;
		this.kharakterer = kharakterer;

	}

	public String toString() {

		// Change the array into a string one character at a time
		String kharaktererString = "";
		for (char kharaktererChar : kharakterer) {

			kharaktererString += kharaktererChar + ", ";

		}

		return fagnr + ", " + fagnavn + ", " + antStudiepoeng + ", " + kharaktererString;
	}

}
