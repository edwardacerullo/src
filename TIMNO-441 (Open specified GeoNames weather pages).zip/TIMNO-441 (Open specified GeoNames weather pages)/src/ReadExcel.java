/** @brief Read an Excel Worksheet

Commands used:

- getContents() 
- getType(), including CellType.LABEL and CellType.NUMBER
- getRows
- getWorkbook
- getCell, with column first then row.

Update the setInputFile 
       and setOutputURL as needed.

@author Edward Cerullo, TimeandDate
@date January, 2016

**/

import java.io.File;
import java.io.IOException;

import org.eclipse.swt.program.*;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {

	public static void main(String[] args) throws IOException {

		System.out.println("Starting to read the spreadsheet to open browsers for TIMNO-441...");

		ReadExcel test = new ReadExcel();
		test.setInputFile("S:/Testing/timeanddate.de/5 Wetter/Wetter in lhrer Stad/TIMNO-441/VariousGeoNames.xls");
		// test.setURL("https://test.timeanddate.de/wetter/deutschland/");
		test.setURL("https://test.timeanddate.de/wetter/");
		test.read();

		System.out.println("Finished.");
	}

	// Set the input file
	private String inputFile;
	public void setInputFile(String inputFile) {

		this.inputFile = inputFile;

	}
	
	// Set the output URL
	private String outputURL;
	public void setURL(String outputURL) {
		this.outputURL = outputURL;
	}

	public void read() throws IOException {

		File inputWorkbook = new File(inputFile);

		Workbook wb;

		try {

			wb = Workbook.getWorkbook(inputWorkbook);

			// Get the first sheet
			Sheet sheet = wb.getSheet(0);

			// Loop through the cols and rows

			System.out.println("Cols " + sheet.getColumns() + " Rows " + sheet.getRows());
			
			int y = 0;
			for (int x = 0; x < sheet.getRows(); x = x + 1) {

				// print the GeoNames Number from column 0
				Cell cellZero = sheet.getCell(y, x);
				System.out.println(cellZero.getContents());

				// print the GeoNames Name from column 1
				Cell cellOne = sheet.getCell(y+1, x);
				System.out.println(cellOne.getContents());
				
				// And launch a browser using the GeoNames number
				Program.launch(outputURL + "@" + cellZero.getContents());

			} // x loop

			return;

		} catch (BiffException e) {

			e.printStackTrace();

		}

	}

}