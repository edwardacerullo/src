import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;

/*
 *
 * BonusMedlem
 * 
 */

class BonusMedlem {

	private final int medlNr;
	private final Personalia pers;
	private final LocalDate innmeldtDato;
	private int poeng = 0;

	public BonusMedlem(int medlNr, Personalia pers, LocalDate dato2) {
		this.medlNr = medlNr;
		this.pers = pers;
		innmeldtDato = dato2;

	}

	// getMedlnr
	public int getMedlnr() {

		return medlNr;

	}

	// getPersonalia
	public Personalia getPersonalia() {

		return getPers();

	}

	// getInnmeldt
	public LocalDate getInnmeldtDato() {

		return innmeldtDato;

	}

	// getPoeng
	public int getPoeng() {

		return poeng;

	}

	// finnKvalPoeng
	public int finnKvalPoeng(LocalDate dato2) {

		long dagerMellom = ChronoUnit.DAYS.between(innmeldtDato, dato2);

		// For more than a year, return 0
		if (dagerMellom >= 365) {

			return 0;

		}

		// Otherwise, return the number of points
		return poeng;

	}

	// okPassord
	public boolean okPassord(String passord) {

		return getPers().okPassord(passord);

	}

	// registrerPoeng
	public void registrerPoeng(int poeng) {

		this.poeng += poeng;

	}

	public Personalia getPers() {

		return pers;
		
	}

}