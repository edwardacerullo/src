import java.time.LocalDate;

/*
 *
 * BasicMedlem
 * 
 */

class BasicMedlem extends BonusMedlem {
	
	private final int poengFaktor = 1;

	public BasicMedlem(int medlNr, Personalia pers, LocalDate localDate) {

		super(medlNr, pers, localDate);

	}

	public String toString() {

		return super.toString() + " og er BasicMedlem.";

	}

}