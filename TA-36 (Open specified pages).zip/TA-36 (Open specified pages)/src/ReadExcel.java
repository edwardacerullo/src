/** @brief Read an Excel Worksheet

Commands used:

- getContents() 
- getType(), including CellType.LABEL and CellType.NUMBER
- getRows
- getWorkbook
- getCell, with column first then row.

Update the setInputFile,
       the setUrlPrefix.

@author Edward Cerullo, TimeandDate
@date February, 2017

**/

import java.io.File;
import java.io.IOException;

import org.eclipse.swt.program.*;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {

	public static void main(String[] args) throws IOException {

		System.out.println("Starting to read the spreadsheet to open browsers for TA-36...");

		ReadExcel test = new ReadExcel();
		test.setInputFile("S:/Testing/timeanddate.com/3. Time Zones (time)/timezones/TA-36/Various5.xls");
		test.setUrlPrefix("https://test.timeanddate.com/time/zones/");
		test.read();

		System.out.println("Finished.");
	}

	// Input File
	private String inputFile;
	public void setInputFile(String inputFile) {

		this.inputFile = inputFile;

	}

	// URL Prefix
	private String urlPrefix;
	public void setUrlPrefix(String urlPrefix) {
	
		this.urlPrefix = urlPrefix;
		
	}
	
	public void read() throws IOException {

		File inputWorkbook = new File(inputFile);

		Workbook wb;

		try {

			wb = Workbook.getWorkbook(inputWorkbook);

			// Get the first sheet
			Sheet sheet = wb.getSheet(0);

			// Loop through the cols and rows

			System.out.println("Cols " + sheet.getColumns() + " Rows " + sheet.getRows());
			
			int y = 0;
			for (int x = 0; x < sheet.getRows(); x = x + 1) {

				Cell cell = sheet.getCell(y, x);

				System.out.println(cell.getContents());
				// And launch a browser using the contents of the cell
				Program.launch(urlPrefix + cell.getContents());

			} // x loop

			return;

		} catch (BiffException e) {

			e.printStackTrace();

		}

	}

}