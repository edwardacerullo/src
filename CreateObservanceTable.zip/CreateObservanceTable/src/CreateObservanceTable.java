import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
 
/**
 * @author Edward Cerullo
 * @version 1.0
 * @category create observances table in QA
 */

public class CreateObservanceTable {
 
    /**
     * Create a new table in the test database
     *
     */
    public static void main(String[] args) {
    	
    	// First, load the driver
    	try {
    		
    		Class.forName("com.mysql.jdbc.Driver").newInstance();
    		System.out.println("Driver is loaded...");
    		
    	} catch (Exception errLoad) {
    		
    		System.out.println("Error on load...");
            System.out.println(errLoad.getMessage());
    		
    	}
    	
        // Next, get a connection
    	Connection connection = null;
    	try {
    		
    		connection = DriverManager.getConnection("jdbc:mysql://mur.timeanddate.net?user=eac&password=sqlsqlsql&&useSSL=false");
    		System.out.println("Connection is complete...");
    		
        } catch (SQLException errConnection) {
        	
        	System.out.println("Error on connection...");
            System.out.println("SQL Exception: " + errConnection.getMessage());
            System.out.println("SQL State: " + errConnection.getSQLState());
            System.out.println("SQL Error Code: " + errConnection.getErrorCode());
            
        }
    		
        // SQL USE statement
    	Statement statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "USE QA";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement USE is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on USE statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}

        // SQL DROP statement
    	statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "DROP TABLE observances";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement DROP is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on DROP statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
        // SQL CREATE statement
    	statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = 
            		"CREATE TABLE IF NOT EXISTS observances (\n"
                    + " observance_id int(11) NOT NULL, \n"
            		+ " place_country_id varchar(4) NOT NULL,\n"
            		+ " place_state_id varchar(11) NOT NULL,\n"
            		+ " holiday varchar(256) NOT NULL, \n"
            		+ " when varchar(256) NOT NULL, \n"
            		+ " comments varchar(256) NOT NULL, \n"
            		+ " general_statute varchar(256) NOT NULL, \n"
            		+ " specific_statute varchar(256) NOT NULL, \n"
            		+ " start_year int(4), \n"
            		+ " stop_year int(4), \n"
            		+ " create_date timestamp DEFAULT CURRENT_TIMESTAMP,\n"
                    + " last_change_date timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n"
                    + " CONSTRAINT PK_observance_id PRIMARY KEY (observance_id) \n"
            		+ ");";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement CREATE TABLE is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on CREATE TABLE statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}

        System.out.println("That's all, folks!");
        
    }
 
}