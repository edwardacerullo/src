/*
 * 
 * �ving 5C
 * Spring, 2019
 * Edward Cerullo
 * 
 */

public class Main {
	
    public static void main(String[] args) throws Exception {
    	
        MySQLUpdate �5c = new MySQLUpdate();
        �5c.updateTables();
        
    }

}