import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class MySQLUpdate {

	private Connection connection = null;
	private Statement statement = null;
	private int returnCode = 0;
	private ResultSet genericOutput = null;

	/*
	 * Statuses:
	 * 
	 * 0 = Update to eksemplar is good.
	 * 1 = Update to eksemplar is not good. 
	 * 2 = SQL error while trying to update eksemplar.
	 * 3 = ISBN not found in the boktittel table.
	 * 4 = Error connecting to the local database.
	 * 5 = SQL error while trying to read eksemplar.
	 * 6 = ISBN and Copy not found on eksemplar.
	 * 7 = SQL error while trying to read eksemplar.
	 * 8 = ISBN and Copy already loaned out on eksemplar. 
	 * 
	 */
	
	
	public void updateTables() throws Exception {
		try {

			// Load the JDBC Driver
			Class.forName("com.mysql.jdbc.Driver");

			// Connect to the Database I created locally
			connection = DriverManager
					.getConnection("jdbc:mysql://127.0.0.1:3306/?user=root");

			// Setup the statement to use the Database.
			statement = connection.createStatement();

			// Get the name.
			String borrowerName = JOptionPane
					.showInputDialog("Please enter the borrower's name:");

			// Get the ISBN.
			String bookISBN = JOptionPane
					.showInputDialog("Please enter the ISBN of the book to be borrowed:");

			// Get the copy number.
			String copyNumber = JOptionPane
					.showInputDialog("Please enter the copy number:");

			// Try to update the eksemplar table.
			returnCode = executeUpdate(statement, borrowerName, bookISBN, copyNumber);
			
			if (returnCode != 0) {
				
				System.out.println("(Return Code is " + returnCode + ")");
				
			}

		} catch (Exception error4) {

			throw error4;

		} finally {

			closeupdatabase();

		}

		return;

	}

	/*
	 * Update the eksemplar table.
	 */

	private int executeUpdate(Statement statement2, String borrowerName, String bookISBN, String copyNumber) {

		// First, see if the ISBN is valid in the boktittel table.
		String sqlStatement = "select count(*) antall from boktittel where isbn = " + "'" + bookISBN + "'" + ";";
		ResultSet resultSet;
		try {
			
			resultSet = statement.executeQuery(sqlStatement);

			while (resultSet.next()) {

				int count = Integer.parseInt(resultSet.getString(1));

				if (count == 0) {
					
					System.out.println("ISBN " + bookISBN + " is not on file.");
					return 3;
					
				}

			}

			
		} catch (SQLException error3) {
			
			error3.printStackTrace();
			
		}

		// Next, verify that the copy number is a valid copy number in the eksemplar table.
		sqlStatement = "select isbn, eks_nr from eksemplar where isbn = '" + bookISBN + "' and eks_nr = '" + copyNumber + "';";
		try {
			
			//System.out.println("Looking for " + sqlStatement);
			genericOutput = statement2.executeQuery(sqlStatement);

			if (genericOutput.next()) {

				// Don't do anything here...

			} else {
				
					System.out.println("Copy " + copyNumber + " for ISBN " + bookISBN + " is not on file.");
					return 6;
				
			}
			
		} catch (SQLException error5) {
			
			error5.printStackTrace();
		}

		// Then, verify that the book copy is not already loaned out in the eksemplar table.
		sqlStatement = "select isbn, eks_nr, laant_av from eksemplar where isbn = '" + bookISBN + "' and eks_nr = '" + copyNumber + "';";
		try {
			
			//System.out.println("Looking for " + sqlStatement);
			genericOutput = statement2.executeQuery(sqlStatement);

			while (genericOutput.next()) {

				String isbn = genericOutput.getString(1);
				String eks_nr = genericOutput.getString(2);
				String laant_av = genericOutput.getString(3);
				
				if (laant_av != null) {
					
					System.out.println("Copy " + eks_nr + " for ISBN " + isbn + " is already loaned out to " + laant_av + ". Go track them down!");
					return 8;
					
				}
				
			}
			
		} catch (SQLException error7) {
			
			error7.printStackTrace();
		}
		
		// Finally, try the loan.
		sqlStatement = "update eksemplar set laant_av = '" + borrowerName + "' where isbn = '" + bookISBN + "' and eks_nr = " + copyNumber + " and laant_av is null;";
		try {
			
			returnCode = statement2.executeUpdate(sqlStatement);

			if (returnCode == 1) {
				
				System.out.println("Book " + bookISBN + " copy " + copyNumber + " was checked out successfully by " + borrowerName);
				return 0;
				
			} else {
				
				System.out.println("Book " + bookISBN + " copy " + copyNumber + " was NOT checked out by " + borrowerName);
				return 1;
				
			}
			
		} catch (SQLException error2) {
			
			error2.printStackTrace();
			return 2;
			
		}

	}

	/*
	 * Close up the database
	 */

	private void closeupdatabase() {
		try {

			if (connection != null) {
				connection.close();
			}

		} catch (Exception error2) {

			System.out.print("Error on database close: " + error2);

		}

	}

}