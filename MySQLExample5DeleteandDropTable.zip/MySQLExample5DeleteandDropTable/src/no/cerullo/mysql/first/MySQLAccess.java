package no.cerullo.mysql.first;

import java.sql.*;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class MySQLAccess {

 	public void readDataBase() throws Exception {
 
 		System.out.println("Defining the data source...");
 		MysqlDataSource dataSource = new MysqlDataSource();
 		dataSource.setUrl("jdbc:mysql://mur.timeanddate.net/QA");
 		dataSource.setUser("eac");
 		dataSource.setPassword("Time0123&");
 		
 		System.out.println("Connecting...");
 		Connection conn = dataSource.getConnection();
 		
 		// Initialize the statement variable
 		Statement stmt = null;
 	    String query1 = "DELETE FROM `comments1` WHERE id = 2;";
 	    String query2 = "DELETE FROM `comments1` WHERE id = 1;";
 	    String query3 = "DROP TABLE comments1;";
 	    try {
 	    	
 	    	stmt = conn.createStatement();
 	    	System.out.println("Executing the SQL1...");
 	    	int stat = stmt.executeUpdate(query1);
 	    	System.out.println("Status = " + stat);

 	    	System.out.println("Executing the SQL2...");
 	    	stat = stmt.executeUpdate(query2);
 	    	System.out.println("Status = " + stat);
 	    	
 	    	System.out.println("Executing the SQL3...");
 	    	stat = stmt.executeUpdate(query3);
 	    	System.out.println("Status = " + stat);
 	    	
 	    } catch (SQLException e ) {
 	        // TODO
 	    } finally {
 	        if (stmt != null) { stmt.close(); }
 	    }
 	     		
 		System.out.println("Closing statement...");
 		stmt.close();
 		System.out.println("Closing connection...");
 		conn.close(); 		
 		
    }

}