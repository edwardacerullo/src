package no.cerullo.mysql.first.test;

import no.cerullo.mysql.first.MySQLAccess;

public class Main {
    public static void main(String[] args) throws Exception {
    	
    	System.out.println("Creating the object...");
        MySQLAccess dao = new MySQLAccess();
        dao.readDataBase();
    }

}