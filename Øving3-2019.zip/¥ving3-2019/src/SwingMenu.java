
/*
Java Swing, 2nd Edition
By Marc Loy, Robert Eckstein, Dave Wood, James Elliott, Brian Cole
ISBN: 0-596-00408-7
Publisher: O'Reilly 
 */
// MenuExample.java
// A simple example of constructing and using menus.
//

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.BevelBorder;

// This is for the prompts
import static javax.swing.JOptionPane.*;

public class SwingMenu extends JPanel {

	/*
	 * This is the array.
	 */
	KonferanseSenter konferanseSenter = new KonferanseSenter();

	/*
	 * Setup a Java Swing menu Stolen shamelessly from The Internets.
	 */

	static int menuOption = 0;

	private static final long serialVersionUID = 1L;

	public JTextPane pane;

	public JMenuBar menuBar;

	public SwingMenu() {
		menuBar = new JMenuBar();
		JMenu formatMenu = new JMenu("Room Reservation System -- Main Menu");
		formatMenu.setMnemonic('R');

		MenuAction optionOne = new MenuAction("1 Reserver rom.", new ImageIcon("1.png"));
		MenuAction optionTwo = new MenuAction("2 Registrer nytt rom i rom inventory.", new ImageIcon("2.png"));
		MenuAction optionThr = new MenuAction("3 Finn antall rom fra rom inventory.", new ImageIcon("3.png"));
		MenuAction optionFou = new MenuAction("4 Finn bestemt rom (By Sequence).", new ImageIcon("4.png"));

		MenuAction optionFiv = new MenuAction("5 Finn bestemt rom (By Rom Nummer).", new ImageIcon("5.png"));
		MenuAction optionExi = new MenuAction("Exit.", new ImageIcon("5.png"));

		JMenuItem item;
		item = formatMenu.add(optionOne);
		item.setMnemonic('1');
		item = formatMenu.add(optionTwo);
		item.setMnemonic('2');
		item = formatMenu.add(optionThr);
		item.setMnemonic('3');
		item = formatMenu.add(optionFou);
		item.setMnemonic('4');
		item = formatMenu.add(optionFiv);
		item.setMnemonic('5');
		item = formatMenu.add(optionExi);
		item.setMnemonic('E');

		menuBar.add(formatMenu);
		menuBar.setBorder(new BevelBorder(BevelBorder.RAISED));

	}

	class MenuAction extends AbstractAction {

		/*
		 * Do what the user wants
		 */

		private static final long serialVersionUID = 1L;

		public MenuAction(String text, Icon icon) {
			super(text, icon);
		}

		public void actionPerformed(ActionEvent e) {
			try {

				// pane.getStyledDocument().insertString(0,
				// "Action [" + e.getActionCommand() + "] performed!\n",
				// null);

				if (e.getActionCommand() == "1 Reserver rom.") {
					menuOption = 1;
				} else if (e.getActionCommand() == "2 Registrer nytt rom i rom inventory.") {
					menuOption = 2;
				} else if (e.getActionCommand() == "3 Finn antall rom fra rom inventory.") {
					menuOption = 3;
				} else if (e.getActionCommand() == "4 Finn bestemt rom (By Sequence).") {
					menuOption = 4;
				} else if (e.getActionCommand() == "5 Finn bestemt rom (By Rom Nummer).") {
					menuOption = 5;
				} else if (e.getActionCommand() == "Exit.") {
					return;
				}

				performAction(menuOption);

			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}

		private void performAction(int menuOption) {

			/*
			 * And, on to the reservations.
			 */

			switch (menuOption) {

			// This is something of an error
			case 0:
				// System.out.println("This is option 0.");
				return;

			// Reserver rom
			case 1:
				// System.out.println("This is option 1.");
				performReserverRom();
				break;

			// Registrer nytt rom
			case 2:
				// System.out.println("This is option 2.");
				performRegistrerNyttRom();
				break;

			// Finn antall rom
			case 3:
				// System.out.println("This is option 3.");
				performFinnAntallRom();
				break;

			// Finn bestemt room via the array index
			case 4:
				// System.out.println("This is option 4.");
				performFinnBestemtRomBySequence();
				break;

			// Finn bestemt room via the room number
			case 5:
				// System.out.println("This is option 5.");
				performFinnBestemtRomByRomNummer();
				break;

			// Possible error?
			default:

				System.out.println("That's all folks!");
				break;

			}

		}

		/*
		 * Option 5 -- enter the room number, display the reservation date and
		 * time.
		 */

		private void performFinnBestemtRomByRomNummer() {

			int romNummer = Integer.parseInt(showInputDialog("Enter rom nummer: "));

			try {

				showMessageDialog(null, konferanseSenter.finnRomViaNummer(romNummer).toString());

			} catch (NullPointerException errnps)

			{

				showMessageDialog(null, "Ingen funnet by Rom Nummer.");

			}

		}

		/*
		 * Option 4 -- Enter the sequence number, display the reservation date
		 * and time.
		 */

		private void performFinnBestemtRomBySequence() {

			int index = Integer.parseInt(showInputDialog("Enter rom sequencenummer: "));

			try {

				showMessageDialog(null, konferanseSenter.finnRomViaIndeks(index).toString());

			} catch (NullPointerException errnpe)

			{

				showMessageDialog(null, "Ingen funnet by Seq Nummer.");

			}

		}

		/*
		 * Option 3 -- display the number of rooms and a list of the room
		 * numbers in the facility.
		 */

		private void performFinnAntallRom() {

			try {

				showMessageDialog(null, "Antall rom er " + konferanseSenter.finnAntRom() + "\n" + "= Rom Inventory ="
						+ konferanseSenter.finnReservasjoner());

			} catch (NullPointerException errnpe)

			{

				showMessageDialog(null, "Ingen funnet fra rom inventory.");

			}

		}

		/*
		 * Option 2 -- Create a room.
		 */

		private void performRegistrerNyttRom() {

			/*
			 * Collect the room number and the capacity
			 */

			int romNummer = Integer.parseInt(showInputDialog("Enter romnummer: "));
			int romCapacity = Integer.parseInt(showInputDialog("Enter max antall av personer: "));

			if (konferanseSenter.registrerRom(romNummer, romCapacity)) {

				showMessageDialog(null,
						"Rom nummer " + romNummer + " med " + romCapacity + " max persons. Registration er vellykket");

			} else {

				showMessageDialog(null, "Registration er ikke god. (For en eller annen grunn...).");

			}

		}

		/*
		 * Option 1 -- Reserve a room.
		 */

		private void performReserverRom() {

			/*
			 * Get a:
			 * 
			 * - Customer Name - Customer Telephone Number - Date -- yymmdd -
			 * From Time -- hhmm - To Time -- hhmm
			 * 
			 * Then convert the date and times to integers so they can be used
			 * by the LocalDate and LocalTime functions. Finally, use LocalDate
			 * and LocalTime in the LocalDateTime function.
			 *
			 */

			String navn = showInputDialog("Din navn: ");

			String telefonNummer = showInputDialog("Din telefon nummer: ");

			int antPerson = Integer.parseInt(showInputDialog("Antall person(er) i rom: "));

			String resDate = showInputDialog("Reservasjon dato ((i ����mmdd format): ");
			int resYYYYMMDD = Integer.valueOf(resDate);
			int resYearInt = resYYYYMMDD / 10000;
			int resMMDD = (resYYYYMMDD - (resYearInt * 10000));
			int resMonthInt = resMMDD / 100;
			int resDayInt = resMMDD - (resMonthInt * 100);

			String resFraTid = showInputDialog("Fra tid (i hhmm format): ");
			int resHHMM = Integer.valueOf(resFraTid);
			int resFraHrInt = resHHMM / 100;
			int resFraMnInt = (resHHMM - (resFraHrInt * 100));

			String resTilTid = showInputDialog("Til tid (i hhmm format): ");
			resHHMM = Integer.valueOf(resTilTid);
			int resTilHrInt = resHHMM / 100;
			int resTilMnInt = (resHHMM - (resTilHrInt * 100));

			// System.out.println("resYearInt,resMonthInt,resDayInt is " +
			// resYearInt + ", " + resMonthInt + ", " + resDayInt );
			// System.out.println("resFraHrInt,resFraMnInt is " + resFraHrInt +
			// ", " + resFraMnInt);
			// System.out.println("resTilHrInt,resTilMnInt is " + resTilHrInt +
			// ", " + resTilMnInt);

			LocalDate localDate = LocalDate.of(resYearInt, resMonthInt, resDayInt);
			LocalTime localFraTime = LocalTime.of(resFraHrInt, resFraMnInt, 0, 0);
			LocalTime localTilTime = LocalTime.of(resTilHrInt, resTilMnInt, 0, 0);

			LocalDateTime fraTid = LocalDateTime.of(localDate, localFraTime);
			LocalDateTime tilTid = LocalDateTime.of(localDate, localTilTime);

			// System.out.println("FraTid is " + fraTid);
			// System.out.println("TilTid is " + tilTid);

			try {

				/*
				 * Build up the request for reserverRom in KonferanseSenter:
				 * 
				 * - Kunde is the name and the telephone number - Reservasjon is
				 * the from time, to time, and the Kunde. - antPerson is entered
				 * by the user.
				 */
				Kunde kunde1 = new Kunde(navn, telefonNummer);
				Reservasjon res1 = new Reservasjon(fraTid, tilTid, kunde1);

				int romNummer = konferanseSenter.reserverRom(res1, antPerson);

				if (romNummer > 0) {

					showMessageDialog(null, "Reservasjonen er vellykket i rom nummer: " + romNummer + ".");

				} else {

					showMessageDialog(null, "Reservasjonen er ikke vellykket");
				}

			} catch (IllegalArgumentException error) {

				showMessageDialog(null, "An error has occurred: " + error.getMessage());

			}

		}

	}

	public static void main(String[] args) {

		/*
		 * Swing Menu -- shamelessly copied from somewhere on The Internets
		 * http://www.java2s.com/Code/Java/Swing-JFC/
		 * Asimpleexampleofconstructingandusingmenus.htm
		 * 
		 */

		SwingMenu example = new SwingMenu();
		example.pane = new JTextPane();
		example.pane.setPreferredSize(new Dimension(250, 250));
		example.pane.setBorder(new BevelBorder(BevelBorder.LOWERED));

		JFrame frame = new JFrame("= Venus de Milo Arms =");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setJMenuBar(example.menuBar);
		frame.getContentPane().add(example.pane, BorderLayout.CENTER);
		frame.pack();
		frame.setVisible(true);

	}

}