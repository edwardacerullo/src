/*
 * 
 * Check the various times 
 * 
 */

class Tidspunkt implements Comparable<Tidspunkt> {

	private final long tid;

	public Tidspunkt(long tid) {

		this.tid = tid;

	}

	public long getTidspunkt() {

		return tid;

	}

	/* 
	 * Check a time.
	 * Return -1 if the passed time is greater than tid.
	 * Return 1 if the passed time is less than tid.
	 * Return 0 if the two passed times are equal.
	 */
	
	public int compareTo(Tidspunkt compTid) {

		if (tid < compTid.tid) {

			return -1;

		} else if (tid > compTid.tid) {

			return 1;

		} else {

			return 0;

		}

	}

}