import Project5C.MySQLUpdate;

public class Main {
	
    public static void main(String[] args) throws Exception {
    	
        MySQLUpdate p5c = new MySQLUpdate();
        p5c.updateTables();
        
    }

}