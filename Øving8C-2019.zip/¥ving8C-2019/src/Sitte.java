/*
 * �ving8B, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class Sitte extends Tribune {

	// Sitte = Tribune + antOpptatt
	private int [] antOpptatt;  // tabellst�rrelse: antall rader
	
	public Sitte(String tribunenavn, int kapasitet, int pris, int antRadars) {
		super(tribunenavn, kapasitet, pris);
		// TODO Auto-generated constructor stub
		antOpptatt = new int[antRadars];
	}

	// Part B: Add finnAntallSolgteBilletter
	public int finnAntallSolgteBilletter() {

		return super.finnAntallSolgteBilletter();

	}

	// Part B: Add finnInntekt
	public int finnInntekt() {

		return (getPris() * super.finnAntallSolgteBilletter());

	}

	// Part B: Gotta add this one too
	// TODO This looks fishy, but adding the super got rid of the error message!
	public int getPris() {

		return super.getPris();

	}
	
	// Part C: kjopBilletter number 1 -- number of tickets required
	public Billett[] kjopBilletter(int antBilletts) {
		
        Billett[] billettListe = new Billett[antBilletts];
        
        int ledig = getFreePlass(antBilletts);
        
        if (ledig != -1) { 
        	
        	if ((getKapasitet() - finnAntallSolgteBilletter()) >= antBilletts) {
        	
        		for(int i = 0; i < antBilletts; i++) {
            	
        			int freeRows = getFreePlass(antBilletts);
        			// Increment 
        			antOpptatt[freeRows]++;
        			// Create a new Sitteplass Billett
        			SitteplassBillett billetten = new SitteplassBillett(getTribunenavn(), getPris(), antOpptatt[freeRows], freeRows);
        			billettListe[i] = billetten;
                
        		}
        	
        	}
            
        } else {
        	
            return null;
            
        }
        
        return billettListe;
        
    }
	
	// Part C: kjopBilletter number 2 -- text strings as input and return a name list
	public Billett[] kjopBilletter(String[] navnList) {

		return kjopBilletter(navnList.length);

	}

	// Part C: getFreePlass
	private int getFreePlass(int antBilletts) {
		
        int kapasitetPerRow = getKapasitet() / antOpptatt.length;

        if (antBilletts > getKapasitet()) {
            return -1;
        }

        // Loop thru
        for (int i = 0; i < antOpptatt.length; i++) {
        	
        	// Do we have capacity?
            if (antOpptatt[i] < kapasitetPerRow) {
            	
            	// Do we have tickets left?
            	if ((kapasitetPerRow - antOpptatt[i]) >= antBilletts) {

            		return i; // return the number
            	
            	}
            	
            }
            	
        }

        return -1; // Invalid return
        
    }
	
}