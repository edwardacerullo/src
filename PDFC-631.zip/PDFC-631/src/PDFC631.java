import java.net.*;
import java.io.*;

/**
 * 
 * @author Edward Cerullo <eac@timeanddate.com>
 *
 * Check the size of a URL and set a return code for Jenkins to use.
 * 
 */

public class PDFC631 {

	public static void main(String[] args) throws Exception {
	
		URL oracle = new URL("https://otac.murtest.timeanddate.com/scripts/calpreview.php?site=1&typ=3&tpl=1&country=18&_country=18&cst=0&lang=en&cmode=1&ccol1=ef0471&ccol2=1397e7&cpa=4&ori=1&fsz=0&fdow=0&hol=4194329&wno=1&mphase=1&hnp=0&year=2019&month=11&years=1");
		URLConnection conn = oracle.openConnection();
		long completeFileSize = conn.getContentLength();
		setReturnCode(completeFileSize);

	} // main

	private static int setReturnCode(long completeFileSize) {
		
		if (completeFileSize > 10000) {
			
			return 0; // Good
			
		} else {
			
			return 1; // We have a problem!
			
		}
		
	} // setReturnCode

} // class