import java.sql.*;
import java.io.*;

/**
 * @author Edward Cerullo
 * @version 1.0
 * @category flash_cards_* tables in QA
 */

public class DisplayTable {

	private static Connection connection = null;
	private static String hexColor;
	private static String font = null;
	private static String fontSize = null;
	private static String borderStyle = null;
	private static String[][] displayText = new String[5][2];
	
	/**
	 * Display the contents of some tables in the test database
	 *
	 */
	public static void main(String[] args) {

		// First, load the driver
		LoadDriver();

		// Next, get a connection
		EstablishConn();

		// Use the connection
		ExecuteUse();

		// These are the common variables
		
		// Get the header record
		GetHeader();

		// Get the parameter record
		GetParameter();

		// Get the detail records
		GetDetail();

		// Put HTML
		PutHTML();

		System.out.println("That's all, folks!");

	}

	/*
     * Create the HTML files 
     */
	private static void PutHTML() {

		// The Q card
		try {
			
			StringBuilder htmlStringBuilder = new StringBuilder();
			htmlStringBuilder.append("<html>\n");
			htmlStringBuilder.append("<head>\n");
			htmlStringBuilder.append("<title>\n");
			htmlStringBuilder.append("Time and Date Tools for Schools");
			htmlStringBuilder.append("</title>\n");
			htmlStringBuilder.append("</head>\n");
			htmlStringBuilder.append("<body>\n");
			// Table
			htmlStringBuilder.append("<table ");
			htmlStringBuilder.append("width=\"");
			htmlStringBuilder.append("500");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("align=\"");
			htmlStringBuilder.append("center");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("border=\"");
			htmlStringBuilder.append("1");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("border-style=\"");
			htmlStringBuilder.append(borderStyle);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("font=\"");
			htmlStringBuilder.append(font);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("font-size=\"");
			htmlStringBuilder.append(fontSize);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("bordercolor=\"");
			htmlStringBuilder.append(hexColor);
			htmlStringBuilder.append("\">\n");
			// Row 1
			htmlStringBuilder.append("<tr><td ");
			htmlStringBuilder.append("height=\"");
			htmlStringBuilder.append("50%");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("align=\"");
			htmlStringBuilder.append("center");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("\">");
			htmlStringBuilder.append(displayText[0][0]);
			htmlStringBuilder.append("</td></tr>");
			// End of Table
			htmlStringBuilder.append("<caption align=\"bottom\">");
			htmlStringBuilder.append("File name: ");
			htmlStringBuilder.append("file1.html"); //TODO
			htmlStringBuilder.append("</Caption>");
			htmlStringBuilder.append("</table>\n");
			htmlStringBuilder.append("</body>\n");
			htmlStringBuilder.append("</html>\n");
			
			WriteFile(htmlStringBuilder.toString(),"file1.html"); //TODO))
			
		} catch (IOException err1) {
			
			System.out.println("Error on HTML...");
			System.out.println(err1.getMessage());
			err1.printStackTrace();
			
		}

		// The A card
		try {
			
			StringBuilder htmlStringBuilder = new StringBuilder();
			htmlStringBuilder.append("<html>");
			htmlStringBuilder.append("<head>");
			htmlStringBuilder.append("<title>");
			htmlStringBuilder.append("Time and Date Tools for Schools");
			htmlStringBuilder.append("</title>");
			htmlStringBuilder.append("</head>");
			htmlStringBuilder.append("<body>");
			// Table
			htmlStringBuilder.append("<table ");
			htmlStringBuilder.append("width=\"");
			htmlStringBuilder.append("500");
			htmlStringBuilder.append("\" ");			
			htmlStringBuilder.append("align=\"");
			htmlStringBuilder.append("center");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("border=\"");
			htmlStringBuilder.append("1");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("border-style=\"");
			htmlStringBuilder.append(borderStyle);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("font=\"");
			htmlStringBuilder.append(font);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("font-size=\"");
			htmlStringBuilder.append(fontSize);
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("bordercolor=\"");
			htmlStringBuilder.append(hexColor);
			htmlStringBuilder.append("\">\n");
			// Row 1
			htmlStringBuilder.append("<tr><td ");
			htmlStringBuilder.append("height=\"");
			htmlStringBuilder.append("50%");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("align=\"");
			htmlStringBuilder.append("center");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("\">");
			htmlStringBuilder.append(displayText[0][0]);
			htmlStringBuilder.append("</td></tr>");
			// Row 2
			htmlStringBuilder.append("<tr><td ");
			htmlStringBuilder.append("height=\"");
			htmlStringBuilder.append("50%");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("align=\"");
			htmlStringBuilder.append("center");
			htmlStringBuilder.append("\" ");
			htmlStringBuilder.append("\">");
			htmlStringBuilder.append(displayText[0][1]);
			htmlStringBuilder.append("</td></tr>");
			// End of Table
			htmlStringBuilder.append("<caption align=\"bottom\">");
			htmlStringBuilder.append("File name: ");
			htmlStringBuilder.append("file2.html"); //TODO
			htmlStringBuilder.append("</Caption>");
			htmlStringBuilder.append("</table>\n");
			htmlStringBuilder.append("</body>\n");
			htmlStringBuilder.append("</html>\n");
			WriteFile(htmlStringBuilder.toString(),"file2.html");
			
		} catch (IOException err1) {
			
			System.out.println("Error on HTML...");
			System.out.println(err1.getMessage());
			err1.printStackTrace();
			
		}
		
	}

	/*
	 * Write to the HTML file
	 * Make a backup copy of what was there, if a file already exists
	 */
	public static void WriteFile(String fileContents, String fileName) throws IOException {

		// Get the default path
		String projectPath = System.getProperty("user.dir");
		// Create a work area
        String tempFile = projectPath 
        		+ File.separator
        		+ fileName;
        File file = new File(tempFile);
        // If file exists, then delete it and create a new file
        if (file.exists()) {
        	
            try {
            	
                File newFileName = new File(projectPath 
                		+ File.separator
                		+ "old_"
                		+ fileName);
                file.renameTo(newFileName);
                file.createNewFile();
                
            } catch (IOException err2) {

    			System.out.println("Error on file...");
    			System.out.println(err2.getMessage());
    			err2.printStackTrace();
                
            }
            
        }
        
        //write to file with OutputStreamWriter
        OutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
        Writer writer=new OutputStreamWriter(outputStream);
        writer.write(fileContents);
        writer.close();
		
	}
	
	/*
	 * Load the driver
	 */
	private static void LoadDriver() {

		try {

			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("Driver is loaded...");

		} catch (Exception errLoad) {

			System.out.println("Error on load...");
			System.out.println(errLoad.getMessage());

		}

	}

	/*
	 * Establish the connection
	 */
	private static void EstablishConn() {

		try {

			connection = DriverManager
					.getConnection("jdbc:mysql://mur.timeanddate.net?user=eac&password=Java0123&&useSSL=false");
			System.out.println("Connection is complete...");

		} catch (SQLException errConnection) {

			System.out.println("Error on connection...");
			System.out.println("SQL Exception: " + errConnection.getMessage());
			System.out.println("SQL State: " + errConnection.getSQLState());
			System.out.println("SQL Error Code: " + errConnection.getErrorCode());

		}

	}

	/*
	 * USE
	 */
	private static void ExecuteUse() {

		// SQL USE statement
		Statement statement = null;
		try {

			statement = connection.createStatement();

			String sqlStatement = "USE QA";
			statement.executeUpdate(sqlStatement);
			System.out.println("Statement USE is complete...");

		} catch (SQLException errStatement) {

			System.out.println("Error on USE statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
			System.out.println("SQL State: " + errStatement.getSQLState());
			System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();

		}

	}

	/*
	 * SELECT from hdr file
	 */
	private static void GetHeader() {

		// flash_cards_hdr
		// SQL SELECT statement
		Object statement = null;
		try {

			statement = connection.createStatement();

			String sqlStatement = "SELECT set_description FROM flash_cards_hdr "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsHeader;
			rsHeader = ((Statement) statement).executeQuery(sqlStatement);
			while (rsHeader.next()) {
				String setDescription = rsHeader.getString(1);
				System.out.println("setDescription " + setDescription);
			}
			
			System.out.println("Statement SELECT is complete...");

		} catch (SQLException errStatement) {

			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
			System.out.println("SQL State: " + errStatement.getSQLState());
			System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();

		}

	}

	/*
	 * SELECT from prm file
	 */
	private static void GetParameter() {

		// flash_cards_prm
		// SQL SELECT statement
		Object statement = null;
		try {

			statement = connection.createStatement();

			String sqlStatement = "SELECT hex_color, font, font_size, border_style " + "FROM flash_cards_prm "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsParameter;
			rsParameter = ((Statement) statement).executeQuery(sqlStatement);
			while (rsParameter.next()) {
				hexColor = rsParameter.getString("hex_color");
				font = rsParameter.getString("font");
				fontSize = rsParameter.getString("font_size");
				borderStyle = rsParameter.getString("border_style");
				System.out.println("4 Parms: " + hexColor + font + fontSize + borderStyle);
			}
			
			System.out.println("Statement SELECT is complete...");

		} catch (SQLException errStatement) {

			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
			System.out.println("SQL State: " + errStatement.getSQLState());
			System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();

		}

	}

	/*
	 * SELECT from dtl file
	 */
	private static void GetDetail() {

		// flash_cards_dtl
		// SQL SELECT statement
		Object statement = null;
		try {

			statement = connection.createStatement();

			String sqlStatement = "SELECT text_1, text_2 " + "FROM flash_cards_dtl "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsDetail;
			rsDetail = ((Statement) statement).executeQuery(sqlStatement);
			int x = 0; // TODO for the moment, we only want 5x2
			while (rsDetail.next() && (x <= 4)) {
				displayText[x][0] = rsDetail.getString("text_1");
				displayText[x][1] = rsDetail.getString("text_2");
				System.out.println("2 texts: " + displayText[x][0] + displayText[x][1]);
				x++;
			}
			
			System.out.println("Statement SELECT is complete...");

		} catch (SQLException errStatement) {

			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
			System.out.println("SQL State: " + errStatement.getSQLState());
			System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();

		}

	}

}