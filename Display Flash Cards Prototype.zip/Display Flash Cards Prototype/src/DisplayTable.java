import java.sql.*;
 
/**
 * @author Edward Cerullo
 * @version 1.0
 * @category flash_cards_* tables in QA
 */

public class DisplayTable {
 
    private static Connection connection = null;

	/**
     * Display the contents of some tables in the test database
     *
     */
    public static void main(String[] args) {

    	// First, load the driver
    	loadDriver();
    	
        // Next, get a connection
    	establishConn();
    	
    	// Use the connection
    	executeUse();
    		
    	// Get the header record
    	getHeader();
    	
    	// Get the parameter record
    	getParameter();
    	
    	// Get the detail records
    	getDetail();
 
        System.out.println("That's all, folks!");
        
    }


	private static void loadDriver() {

    	try {
    		    		
    		Class.forName("com.mysql.jdbc.Driver").newInstance();
    		System.out.println("Driver is loaded...");
    		
    	} catch (Exception errLoad) {
    		
    		System.out.println("Error on load...");
            System.out.println(errLoad.getMessage());
    		
    	}
    	
    }
    
    private static void establishConn() {
    	
    	try {
    		
    		connection = DriverManager.getConnection("jdbc:mysql://mur.timeanddate.net?user=eac&password=Java0123&&useSSL=false");
    		System.out.println("Connection is complete...");
    		
        } catch (SQLException errConnection) {
        	
        	System.out.println("Error on connection...");
            System.out.println("SQL Exception: " + errConnection.getMessage());
            System.out.println("SQL State: " + errConnection.getSQLState());
            System.out.println("SQL Error Code: " + errConnection.getErrorCode());
            
        }

    }

    private static void executeUse() {
    	
        // SQL USE statement
    	Statement statement = null;
    	try {
    		
			statement = connection .createStatement();
			
			String sqlStatement = "USE QA";
			statement.executeUpdate(sqlStatement);
    		System.out.println("Statement USE is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on USE statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
    }

    private static void getHeader() {
    	
    	// flash_cards_hdr
        // SQL SELECT statement
    	Object statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "SELECT set_description FROM flash_cards_hdr "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsHeader;
			rsHeader = ((Statement) statement).executeQuery(sqlStatement);
			while (rsHeader.next()) {
				String setDescription = rsHeader.getString(1);
				System.out.println("setDescription " + setDescription);
			}
    		System.out.println("Statement SELECT is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
    }
    
    private static void getParameter() {

    	// flash_cards_prm
        // SQL SELECT statement
    	Object statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "SELECT hex_color, font, font_size, border_style "
					+ "FROM flash_cards_prm "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsParameter;
			rsParameter = ((Statement) statement).executeQuery(sqlStatement);
			while (rsParameter.next()) {
				String hexColor = rsParameter.getString("hex_color");
				String font = rsParameter.getString("font");
				String fontSize = rsParameter.getString("font_size");
				String borderStyle = rsParameter.getString("border_style");
				System.out.println("4 Parms: " + hexColor + font + fontSize + borderStyle);
			}
    		System.out.println("Statement SELECT is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
    }
    
    private static void getDetail() {
    	
    	// flash_cards_dtl
        // SQL SELECT statement
    	Object statement = null;
    	try {
    		
			statement = connection.createStatement();
			
			String sqlStatement = "SELECT text_1, text_2 "
					+ "FROM flash_cards_dtl "
					+ "WHERE user = 'eac' and set_name = 'MATH1' ";
			ResultSet rsDetail;
			rsDetail = ((Statement) statement).executeQuery(sqlStatement);
			String[] textOne = new String[5];
			String[] textTwo = new String[5];
			int x = 0;
			while (rsDetail.next()) {
				textOne[x] = rsDetail.getString("text_1");
				textTwo[x] = rsDetail.getString("text_2");
				System.out.println("2 texts: " + textOne[x] + textTwo[x]);
				x++;
			}
    		System.out.println("Statement SELECT is complete...");
			
		} catch (SQLException errStatement) {
			
			System.out.println("Error on SELECT statement...");
			System.out.println("SQL Exception: " + errStatement.getMessage());
            System.out.println("SQL State: " + errStatement.getSQLState());
            System.out.println("SQL Error Code: " + errStatement.getErrorCode());
			errStatement.printStackTrace();
			
		}
    	
    }
    
}