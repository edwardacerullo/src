package com.shop72test1;

/*
 * Testing a page in Chrome with JUnit
 * 
 * 05.11.2018
 * Jira SHOP-72
 * 
 */

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.remote.Augmenter;

public class Shop72Test1 {

	private WebDriver driver;
	private String baseUrl;

	public static Integer r = new Integer(0); /* increment for the result .png */

	/* Setup the parameters. */
	@Before
	public void setUp() throws Exception {

		/*
		 * Point to the driver file
		 */

		System.setProperty("webdriver.chrome.driver", "c:/selenium/chromedriver.exe");
		driver = new ChromeDriver();

		baseUrl = "https://test.clients.timeanddate.com/tadshop/config";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	/* Get the page. */
	@Test
	public void testResult() throws Exception {

		/*
		 * 1. Get the URL.
		 */

		driver.get(baseUrl);
		capturePage(driver);

		/*
		 * 2. Prompt for a userid and enter it.
		 */

		String userid = JOptionPane.showInputDialog("Enter your userid");
		driver.findElement(By.id("username")).sendKeys(userid);
		capturePage(driver);

		/*
		 * 3. Prompt for a password and enter it.
		 */

		String password = JOptionPane.showInputDialog("Enter your password");
		driver.findElement(By.id("password")).sendKeys(password);
		capturePage(driver);

		/*
		 * 4. Press the Submit button.
		 */

		driver.findElement(By.xpath("/html/body/div/div[3]/form/button")).click();

		/*
		 * 5. Prompt for a test prefix (3 random letters should be good.
		 */

		String testMnemonic = JOptionPane.showInputDialog("Enter a test mnemonic");

		/*
		 * 6. And loop thru a variable number of times
		 */

		String testIterations = JOptionPane.showInputDialog("How many tests would you like to run?");
		
		int testIterationsNum = Integer.parseInt(testIterations);
	
		for (int testSeqNum = 1; testSeqNum < (testIterationsNum + 1); testSeqNum = testSeqNum + 1) {

			/*
			 * 6a. Click on the "Add New" button
			 */

			driver.findElement(By.id("newbtn")).click();
			capturePage(driver);

			/*
			 * 6b. Enter the test mnemonic + the test seq number 6c. Enter "VAL" + the test
			 * seq number 6d. Press the Save button
			 * 
			 */

			driver.findElement(By.id("newkey")).sendKeys(testMnemonic + testSeqNum);
			driver.findElement(By.id("newval")).sendKeys("VAL" + testSeqNum);
			capturePage(driver);
			driver.findElement(By.id("savebtn")).click();
			pausePlease(1000);
		}
	}

	/*
	 * Pause for a specified amount of time
	 */
	
	public static void pausePlease(Integer pauseTime) throws InterruptedException {

		try {
			Thread.sleep(pauseTime);
		} catch (InterruptedException error) {
			error.printStackTrace();
		}

	}

	/*
	 * Finish up.
	 */
	
	@After
	public void finishUp() throws Exception {
		driver.quit();
	}

	/*
	 * Capture the current page
	 */
	
	public void capturePage(WebDriver driver) throws InterruptedException {

		/*
		 * Wait a second-and-a-half for the page to render.
		 */

		pausePlease(1500);

		WebDriver tempdriver = driver;
		if (!(driver instanceof TakesScreenshot)) {
			tempdriver = new Augmenter().augment(driver);
		}
		TakesScreenshot screen = (TakesScreenshot) tempdriver;

		/*
		 * Set the path
		 */

		Path captureDirectory = Paths.get(".");

		/*
		 * Set the Running sequence number (3 digits should be enough!)
		 */

		r = r + 1;
		String rS = String.format("%03d", r);

		/*
		 * Get the class name
		 */

		String className = this.getClass().getSimpleName();

		/*
		 * Use the path, class name, and the running sequence number in the file name.
		 */

		Path capture = captureDirectory.resolve(className + "-" + rS + ".png");
		try {

			Files.write(capture, screen.getScreenshotAs(OutputType.BYTES));

		} catch (IOException ex) {

			System.err.println("An IOException was caught: " + ex.getMessage());

		}
	}
}