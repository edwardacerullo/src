
/*
 * �ving8D, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

import javax.swing.JOptionPane;

public class TestProgram {

	public static void main(String[] args) {

		// Standing -- North, South, West -- a.k.a. the cheap seats
		System.out.println("Setup Staa Tribune North");
		Staa staaTribuneN = new Staa("Staa Tribune North", 25, 1000);
		System.out.println("Setup Staa Tribune South");
		Staa staaTribuneS = new Staa("Staa Tribune South", 50, 1000);
		System.out.println("Setup Staa Tribune West");
		Staa staaTribuneW = new Staa("Staa Tribune West", 100, 1000);
		// Sitting -- East
		System.out.println("Setup Sitte Tribune East");
		Sitte sitteTribuneE = new Sitte("Sitte Tribune East", 25, 1000, 20);
		// VIP -- East
		System.out.println("Setup VIP Tribune East");
		VIP vipTribuneE = new VIP("VIP Tribune East", 25, 1000, 10);
		// Put 'em together
		System.out.println("All together now!");
		Tribune[] tribuneInventory = { staaTribuneN, staaTribuneS, staaTribuneW, sitteTribuneE, vipTribuneE };
		System.out.println(tribuneInventory[0].toString());
		System.out.println(tribuneInventory[1].toString());
		System.out.println(tribuneInventory[2].toString());
		System.out.println(tribuneInventory[3].toString());
		System.out.println(tribuneInventory[4].toString());

		// Now, let's make some tickets!

		// Staa Tribune North:
		Billett[] InventoryListStaaN = staaTribuneN.kjopBilletter(3);
		for (Billett billett : InventoryListStaaN) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Staa Tribune South:
		Billett[] InventoryListStaaS = staaTribuneS.kjopBilletter(4);
		for (Billett billett : InventoryListStaaS) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Staa Tribune West:
		Billett[] InventoryListStaaW = staaTribuneW.kjopBilletter(5);
		for (Billett billett : InventoryListStaaW) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}

		// Sitt Tribune East
		Billett[] InventoryListSittE = sitteTribuneE.kjopBilletter(1);
		for (Billett billett : InventoryListSittE) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}
		
		// VIP Tribune East
		String[] case1 = { "Edward" };
		Billett[] InventoryListVIPE = vipTribuneE.kjopBilletter(case1);
		for (Billett billett : InventoryListVIPE) {
			
			JOptionPane.showMessageDialog(null, "This is your ticket -- do not lose it!", billett.toString(), JOptionPane.PLAIN_MESSAGE);
			
		}
		
	}

}
