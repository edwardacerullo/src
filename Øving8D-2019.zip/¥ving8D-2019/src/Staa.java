/*
 * �ving8D, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class Staa extends Tribune {

	// Staa = Trubune + antSolgteBilletter
	private int antSolgteBilletter;

	public Staa(String tribunenavn, int kapasitet, int pris) {
		super(tribunenavn, kapasitet, pris);
		// TODO Auto-generated constructor stub
	}

	// Part B: Add finnAntallSolgteBilletter
	public int finnAntallSolgteBilletter() {

		return antSolgteBilletter;

	}

	// Part B: Add finnInntekt
	public int finnInntekt() {

		return (getPris() * antSolgteBilletter);

	}

	// Part B: Gotta add this one too
	// TODO This looks fishy, but adding the super got rid of the error message!
	public int getPris() {

		return super.getPris();

	}

	// Part C: kjopBilletter number 1 -- number of tickets required
	public Billett[] kjopBilletter(int antBilletts) {

		Billett[] billettListe = new Billett[antBilletts];

        if ((getKapasitet() - antSolgteBilletter) >= antBilletts) {
        	
            for (int i = 0; i < antBilletts; i++) {
            	
            	// Increment
            	antSolgteBilletter++;
            	// Create a new one
                StaaplassBillett staaBillett = new StaaplassBillett(getTribunenavn(), getPris());
                billettListe[i] = staaBillett;
                
            }
            
        } else {
        	
            return null;
            
        }
        
        return billettListe;
        
	}

	// Part C: kjopBilletter number 2 -- text strings as input and return a name list
	public Billett[] kjopBilletter(String[] navnList) {

		return kjopBilletter(navnList.length);

	}
	
}