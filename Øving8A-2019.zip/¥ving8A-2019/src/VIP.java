/*
 * �ving8A, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class VIP extends Sitte {
	
	// VIP = Tribune + Sitte + tilskuer
	private String[][] tilskuer;

	public VIP(String tribunenavn, int kapasitet, int pris, int antRaders) {
		super(tribunenavn, kapasitet, pris, antRaders);
		// TODO Auto-generated constructor stub
		tilskuer = new String[antRaders][getKapasitet() / antRaders];
	}
	
}