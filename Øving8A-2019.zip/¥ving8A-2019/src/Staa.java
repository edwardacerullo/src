/*
 * �ving8A, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public class Staa extends Tribune {
	
	// Staa = Trubune + antSolgteBilletter
	private int antSolgteBilletter;

	public Staa(String tribunenavn, int kapasitet, int pris) {
		super(tribunenavn, kapasitet, pris);
		// TODO Auto-generated constructor stub
	}
	
}