
/*
 * �ving8A, Videreg�ende programmering i Java
 * Due: 31.03.2019
 * 
 * Edward Angelo Cerullo
 * 
 */

public abstract class Tribune {

	// * These are from the assignment
	private final String tribunenavn;
	private final int kapasitet;
	private final int pris;

	public Tribune(String tribunenavn, int kapasitet, int pris) {

		this.tribunenavn = tribunenavn;
		this.kapasitet = kapasitet;
		this.pris = pris;

	}

	// This is needed for VIP.java
	public int getKapasitet() {
		
		return kapasitet;
		
	}

	
	// This is for Tribune.java
	public String getTrubunenavn() {
		
		return tribunenavn;
		
	}
	
	// This is also for Tribune.java
	public int getPris() {
		
		return pris;
		
	}
	
}