
/**
 * @author Edward Cerullo
 * @version 1.0
 * @category TI-2203
 */

public class TI2203 {

	/*
	 * TI2023 List palindrome dates
	 * 
	 * y = year number; start with 999
	 * m = month number 
	 * d = day number
	 * 
	 */

	public static void main(String[] args) {
		
		int x8 = 0;
		int x7 = 0;
		int x6 = 0;
		int x5 = 0;
		int x = 0;

		System.out.println("===== Palindrome Dates =====");
		for (int y = 0, m, d; y++ < 2500;) {

			for (m = 0; m++ < 13;) {

				for (d = 0; d++ < 32;) {

					try {

						java.time.LocalDate.of(y, m, d);

					}

					catch (Exception err1) {

						continue;

					}

					String t = y + String.format("%02d%02d", m, d);

					if (t.contains(new StringBuffer(t).reverse())) {

						x++;
						System.out.println(x + ". Palindrome: " + t);
						
						if (t.length() == 8) {
							x8++;
						} else {
							if (t.length() == 7) {
								x7++;
							} else {
								if (t.length() == 6) {
									x6++;
								} else {
									if (t.length() == 5) {
										x5++;
									}
								}
							}
						}
						
					}

				}
				
			}

		}

		System.out.println("Total: eight-digit palindromes in range: " + x8);
		System.out.println("       seven-digit palindromes in range: " + x7);
		System.out.println("         six-digit palindromes in range: " + x6);
		System.out.println("        five-digit palindromes in range: " + x5);
		
	}
	
}